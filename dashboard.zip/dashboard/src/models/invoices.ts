interface invoices{
  id: Number,
  date: Date,
  voucher_name: string,
  branch: string,
  currency: string,
  party: string,
  quantity: Number,
  gross_amt: Number,
  discount: Number,
  gross_minus_discount: Number,
  net_amount: Number,
  deductions: Number,
  total_value: Number
}
