import {
  install,
  install2
} from "./chunk-OABUQBNF.js";
import "./chunk-KZ4VYYMQ.js";
import "./chunk-XWLXMCJQ.js";
export {
  install2 as CanvasRenderer,
  install as SVGRenderer
};
//# sourceMappingURL=echarts_renderers.js.map
