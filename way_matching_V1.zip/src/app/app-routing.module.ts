import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { DashboardComponent } from './components/dashboard/dashboard.component';
import { StandardComponent } from './components/standard/standard.component';
import { ProcurementComponent } from './components/procurement/procurement.component';
import { ReviewComponent } from './components/review/review.component';
import { DataClassificationComponent } from './components/data-classification/data-classification.component';
import { DuplicateSimilarityComponent } from './components/duplicate-similarity/duplicate-similarity.component';
import { InvoiceChecklistComponent } from './components/invoice-checklist/invoice-checklist.component';
import { InvoiceAuditTrailComponent } from './components/invoice-audit-trail/invoice-audit-trail.component';

const routes: Routes = [

  {
    path:'projects',
    loadChildren: () => import('./components/projects/projects.module').then(m => m.ProjectsModule),
  },
  {
    path: 'dashboard',
    component: DashboardComponent
  },
  {
    path: 'standard',
    component: StandardComponent
  },
  {
    path: 'Procurement',
    component: ProcurementComponent
  },
  {
    path: 'review',
    component: ReviewComponent
  },
  {
    path: 'data-clasification',
    component: DataClassificationComponent
  },
  {
    path: 'duplicat_similarity',
    component: DuplicateSimilarityComponent
  },
  {
    path: 'duplicat_similarity/:id',
    component: DuplicateSimilarityComponent
  },
  {
    path: 'invoice_check_list',
    component: InvoiceChecklistComponent,

  },
  {
    path: 'invoice_check_list_1',
    component: InvoiceAuditTrailComponent,

  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
