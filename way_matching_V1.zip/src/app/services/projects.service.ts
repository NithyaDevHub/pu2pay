import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class ProjectsService {

  constructor(private http: HttpClient) { }

  //Fetch API
  // /get_invoice_full_details/{invoice_number}
  // /get_po_full_details/{po_number}

  getData(TABLE_NAME: string, ID: string) {
    return this.http.get('http://127.0.0.1:8006/get_'+TABLE_NAME+'_full_details/'+ID)
  }


  getPO(){
    // return this.http.get('http://127.0.0.1:8006/get/invoice_details/BATCH-20250428-001');
    // return this.http.get('http://127.0.0.1:8006/get/invoice_details/BATCH-20250428-001');
    return this.http.get('http://127.0.0.1:8006/get_po_full_details/PC24-25_PO%20333');

  }
  getPOLineitems(){
    return this.http.get('http://127.0.0.1:8006/get_records_by_po_id/po_line_items/3');
  }

  //Invoice Data
  getInvoices(){
    // return this.http.get('http://127.0.0.1:8006/get/invoice_details/BATCH-20250428-001');
    return this.http.get('http://127.0.0.1:8006/get_records_by_invoice_no/invoice_details/4');
  }
  getInvoicesLineitems(){
    return this.http.get('http://127.0.0.1:8006/get_records_by_invoice_no/invoice_lineitems/4');
  }
  getInvoiceData(){
    // return this.http.get('http://127.0.0.1:8006/get_invoice_full_details/INB38027A2400169');JAC_24-25_001074
    return this.http.get('http://127.0.0.1:8006/get_invoice_full_details/JAC_24-25_001074');
  }

  //MRN Data
  getMRN(){
    return this.http.get('http://127.0.0.1:8006/get_records_by_grn_no/mrn_details/PC24-25RAO%202');
  }

  getMRNLineitems(){
    return this.http.get('http://127.0.0.1:8006/get_records_by_grn_no/mrn_lineitems/PC24-25RAO%202');
  }


  pdf_conversion_hypotus(){
    return this.http.get('http://127.0.0.1:8006/get_conversion_details')
  }

  // http://127.0.0.1:8006/classification_details
  classification_details(){
    return this.http.get('http://127.0.0.1:8006/classification_details')
  }

  showextraction(claim_id: string){
    return this.http.get(`http://127.0.0.1:8006/get_claim_id_classification_details/${claim_id}`)
  }
  bbox_api(image_path: string){
    return this.http.get(`http://127.0.0.1:8006/get_bbox/${image_path}`)
  }
  get_invoice_po_match(invoice_number: any){
    return this.http.get(`http://127.0.0.1:8006/get_invoice_po_match/${invoice_number}`)
  }
  get_invoice_po_details(){
    return this.http.get(`http://127.0.0.1:8006/invoice_po_details`)
  }

  invoice_po_details_by_id(invoice_number: any){
    return this.http.get(`http://127.0.0.1:8006/invoice_po_details/${invoice_number}`)
  }

  way_match_checklist(invoice_number: any){
    return this.http.get(`http://127.0.0.1:8006/get_3_way_match_checklist/${invoice_number}`)
  }
  get_metadata_checklist(invoice_number: any){
    return this.http.get(`http://127.0.0.1:8006/get_metadata_checklist/${invoice_number}`)
  }
  image_duplicates(id: any){
    return this.http.get(`http://127.0.0.1:8006/image_duplicates/${id}`)
  }
  upload(body:any){
    return this.http.post(`http://127.0.0.1:8006/image_duplicates/upload`, body)
  }

}
