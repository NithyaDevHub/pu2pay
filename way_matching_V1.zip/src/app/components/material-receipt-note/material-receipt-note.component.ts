import { Component, Input } from '@angular/core';
import { ProjectsService } from '../../services/projects.service';

@Component({
  selector: 'app-material-receipt-note',
  templateUrl: './material-receipt-note.component.html',
  styleUrl: './material-receipt-note.component.scss',
})
export class MaterialReceiptNoteComponent {
  mrnData: any;
  mrnLineItem: any;
  mrnDetails: any;
  supplierDetails: any;
  buyerDetails: any;
  invoiceLineItem: any;
  summaryLineItem: any;
  @Input() item:any = '';

  constructor(private projectService: ProjectsService) {}
  ngOnInit() {
    this.getData();
  }

  getData() {
    this.projectService
      .getData('mrn', this.item.mapping_id)
      .subscribe((data: any) => {
        this.mrnDetails = data.mrn_details;
        this.supplierDetails = data.supplier_details[0];
        this.buyerDetails = data.buyer_details[0];
        this.mrnLineItem = data.line_items;
        this.summaryLineItem = data.summary;
        // this.data = data[0];
        console.log(this.buyerDetails);
      });
  }
}
