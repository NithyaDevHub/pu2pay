import { Component } from '@angular/core';
import { ProjectsService } from '../../../services/projects.service';

@Component({
  selector: 'app-project',
  templateUrl: './project.component.html',
  styleUrl: './project.component.scss'
})
export class ProjectComponent {
  isAddCaseOpen = false;
  totalDocuments = 0;
  selectedTab = 'file';
  uploadedFiles: File[] = [];
  constructor( private projectServices: ProjectsService) { }

  ngOnInit(): void {
    // Initialization logic can go here
  }
  

  toggleAddCase(): void {
    this.isAddCaseOpen = !this.isAddCaseOpen;

    if (this.isAddCaseOpen) {
      // Reset form when opening
     
    }
  }
  closeAddCase(): void {
    this.isAddCaseOpen = false;
  }

  setTab(tab: string): void {
    this.selectedTab = tab;
  }

  handleFileUpload(event: any): void {
    const files = event.target.files;
    if (files && files.length) {
      this.uploadedFiles = Array.from(files);
      this.totalDocuments = this.uploadedFiles.length;
    }
  }

  // Add any additional methods or properties needed for the component
  // For example, if you want to fetch data from a service, you can inject the service in the constructor
}
