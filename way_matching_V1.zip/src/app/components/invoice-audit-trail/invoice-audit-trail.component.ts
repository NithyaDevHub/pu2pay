import { Component } from '@angular/core';

@Component({
  selector: 'app-invoice-audit-trail',
  templateUrl: './invoice-audit-trail.component.html',
  styleUrl: './invoice-audit-trail.component.scss'
})
export class InvoiceAuditTrailComponent {

}
