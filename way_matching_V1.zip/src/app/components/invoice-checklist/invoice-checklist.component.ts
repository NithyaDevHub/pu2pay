import { Component } from '@angular/core';

@Component({
  selector: 'app-invoice-checklist',
  templateUrl: './invoice-checklist.component.html',
  styleUrl: './invoice-checklist.component.scss'
})
export class InvoiceChecklistComponent {

}
