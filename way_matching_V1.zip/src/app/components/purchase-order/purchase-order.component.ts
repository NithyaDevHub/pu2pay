import { Component, ElementRef, Input, ViewChild } from '@angular/core';
import { ProjectsService } from '../../services/projects.service';

@Component({
  selector: 'app-purchase-order',
  templateUrl: './purchase-order.component.html',
  styleUrl: './purchase-order.component.scss',
})
export class PurchaseOrderComponent {
  activeTab: string = 'po'; // Default active tab
  data: any;
  poLineItem: any;
  poDetails: any;
  supplierDetails: any;
  buyerDetails: any;
  shippingDetails: any;
  summaryLineItem: any;
  termsAndConditions: any;
  @Input() item:any = '';
  image_path:any
  image_path_image:any
    searchInfoextracted:any;

    @ViewChild('canvas', { static: false }) canvas!: ElementRef<HTMLCanvasElement>;
  searchText: string = 'INVOICE ID';
  searchText1: string = 'romashka';
  imageSrc: any; // Replace with your image
  ctx!: CanvasRenderingContext2D;
  detectedWords: any;


  onTabClick(tab: string): void {
    this.activeTab = tab;
  }
  constructor(private projectService: ProjectsService) {}
  ngOnInit() {
    this.getData();
    console.log("itemitemitemitemitem",this.item)
  }
  getData() {

    this.projectService.getData('po',this.item.mapping_id).subscribe((data: any) => {
    this.data = data[0];
    this.poDetails = data.po_details;
    this.supplierDetails = data.supplier_details[0];
    this.buyerDetails = data.buyer_details[0];
    this.shippingDetails = data.shipping_details[0];
    this.poLineItem = data.line_items;
    this.summaryLineItem = data.summary;
    this.termsAndConditions = data.terms_and_conditions[0];
    this.image_path_image = data.image_path;
    this.image_path = `assets/output_images/${this.item.claim_id}/${this.item.image}`;
      console.log(data);
    });
  }

  ngAfterViewInit() {

    this.loadImage();
    this.detectedWords = this.testing()
  }
  loadImage() {
    // alert("Hi there")
    console.log("this.imageSrc;", this.image_path)
    const canvas = this.canvas.nativeElement;
    this.ctx = canvas.getContext('2d')!;
    const img = new Image();
    img.src = this.image_path;

    img.onload = () => {
      canvas.width = img.width;
      canvas.height = img.height;
      this.ctx.drawImage(img, 0, 0);
    };
  }

  testing(){
    // console.log("image_path", this
    // return this.searchInfoextracted =
    this.projectService.bbox_api(this.image_path_image).subscribe((data: any) => {
      console.log("testing", data)
      // this.imageSrc = data[0].image;
      this.detectedWords =JSON.parse(data[0].bbox);
      console.log("detectedWords", this.detectedWords)
      return this.detectedWords
    })

  }
}
