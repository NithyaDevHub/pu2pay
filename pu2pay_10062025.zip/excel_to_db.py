import os
import pandas as pd
import psycopg2

# Database connection info
DB_HOST = 'localhost'
DB_PORT = '5433'
DB_NAME = 'pu2pay_master'
DB_USER = 'postgres'
DB_PASSWORD = '12345'

# Folder containing PO CSVs
po_folder = r"/Users/fis/Documents/pu2pay/VPR - EY/po"

# Connect to PostgreSQL
conn = psycopg2.connect(
    host=DB_HOST,
    port=DB_PORT,
    dbname=DB_NAME,
    user=DB_USER,
    password=DB_PASSWORD
)
cur = conn.cursor()

# Step 1: Create the vpr_po table
create_table_sql = """
CREATE TABLE IF NOT EXISTS vpr_po (
    id SERIAL PRIMARY KEY,
    Date TEXT,
    Voucher_No TEXT,
    Branch TEXT,
    Currency TEXT,
    Exchange_Rate TEXT,
    Party TEXT,
    Item_Type TEXT,
    Other_Account TEXT,
    Product TEXT,
    UOM TEXT,
    Quantity TEXT,
    Unit_Rate TEXT,
    Gross_Amount TEXT,
    Discount TEXT,
    Gross_Minus_Discount TEXT,
    CGST TEXT,
    SGST TEXT,
    IGST TEXT,
    CESS TEXT,
    GST_Amount TEXT,
    Net_Amount TEXT,
    Net_Amount_In_Company_Currency TEXT,
    Division TEXT,
    Quarter TEXT
);
"""
cur.execute(create_table_sql)
conn.commit()

# Step 2: Process each CSV file
for filename in os.listdir(po_folder):
    if filename.endswith('.csv'):
        quarter = os.path.splitext(filename)[0].split('_')[0]  # e.g., Q1_PO_2024.csv → Q1
        file_path = os.path.join(po_folder, filename)

        df = pd.read_csv(file_path)
        df = df.fillna('')
        df = df.rename(columns=lambda x: x.strip())

        # Drop SNo if present
        if 'SNo' in df.columns:
            df = df.drop(columns=['SNo'])

        # Add Quarter column
        df['Quarter'] = quarter

        # Expected column order
        expected_columns = [
            'Date', 'Voucher No', 'Branch', 'Currency', 'Exchange Rate', 'Party',
            'Item Type', 'Other Account', 'Product', 'UOM', 'Quantity',
            'Unit Rate', 'Gross Amount', 'Discount', 'Gross Minus Discount',
            'CGST', 'SGST', 'IGST', 'CESS', 'GST Amount', 'Net Amount',
            'Net Amount In Company Currency', 'Division', 'Quarter'
        ]

        try:
            df = df[expected_columns]  # Ensure correct column order
        except KeyError as e:
            print(f"❌ Column mismatch in {filename}: {e}")
            continue

        # Insert into database
        insert_sql = """
        INSERT INTO vpr_po (
            Date, Voucher_No, Branch, Currency, Exchange_Rate, Party,
            Item_Type, Other_Account, Product, UOM, Quantity,
            Unit_Rate, Gross_Amount, Discount, Gross_Minus_Discount,
            CGST, SGST, IGST, CESS, GST_Amount, Net_Amount,
            Net_Amount_In_Company_Currency, Division, Quarter
        ) VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s,
                  %s, %s, %s, %s, %s, %s, %s, %s, %s, %s,
                  %s, %s, %s);
        """

        for _, row in df.iterrows():
            cur.execute(insert_sql, tuple(row))

        conn.commit()
        print(f"✅ Inserted: {filename}")

# Cleanup
cur.close()
conn.close()
print("✅ All PO files processed and inserted into `vpr_po`.")
