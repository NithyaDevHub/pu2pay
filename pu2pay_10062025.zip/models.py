from pydantic import BaseModel
from typing import Optional, List
from datetime import datetime,date


class InvoiceDetailsAndSummary(BaseModel):
    invoice_number: str
    invoice_date: str
    total_amount: str
    po_ref: Optional[str] = ""
    company_name: Optional[str] = ""
    supplier_name: Optional[str] = ""
    gstin_supplier: Optional[str] = ""
    buyer_gstin: Optional[str] = ""
    ship_to_address: Optional[str] = ""

    # Summary fields
    total_discount_value: Optional[str] = "0"
    total_quantity: Optional[str] = "0"
    total_taxable_amount: Optional[str] = "0"
    tcs_rate: Optional[str] = ""
    taxable_value: Optional[str] = "0"
    total_cgst_amount: Optional[str] = "0"
    total_sgst_amount: Optional[str] = "0"
    total_tax_amount: Optional[str] = "0"
    total_invoice_value: Optional[str] = "0"
    
    # Buyer details
    buyer_company_name: Optional[str] = ""
    buyer_address: Optional[str] = ""
    buyer_state: Optional[str] = ""
    buyer_state_code: Optional[str] = ""
    buyer_pan: Optional[str] = ""
    buyer_cin: Optional[str] = ""

    # Shipping details
    ship_to_company_name: Optional[str] = ""
    ship_to_state: Optional[str] = ""
    ship_to_state_code: Optional[str] = ""
    ship_to_gstin: Optional[str] = ""
    ship_to_pan: Optional[str] = ""
    ship_to_cin: Optional[str] = ""
    
    
    # Supplier detail fields
    supplier_name: Optional[str]
    pan_supplier: Optional[str]
    udyam_regno: Optional[str]
    state: Optional[str]
    state_code: Optional[str]
    supplier_address: Optional[str]
    gstin_supplier: Optional[str] = None



class InvoiceDetails(BaseModel):
    supplier_name: Optional[str] = None
    supplier_address: Optional[str] = None
    invoice_number: Optional[str] = None
    invoice_date: Optional[str] = None  # Keep as str, FastAPI will auto-parse date
    total_amount: Optional[float] = None
    pan_supplier: Optional[str] = None
    gstin_supplier: Optional[str] = None
    gstin_buyer: Optional[str] = None
    bill_to: Optional[str] = None
    bill_to_address: Optional[str] = None
    ship_to: Optional[str] = None
    ship_to_address: Optional[str] = None
    po_ref: Optional[str] = None
    batch_id: Optional[str] = None
    company_name: Optional[str] = None
    buyer_gstin: Optional[str] = None
    delivery_location: Optional[str] = None

class InvoiceSupplierDetails(BaseModel):
    invoice_id: int
    pan_supplier: Optional[str] = None
    gstin_supplier: Optional[str] = None
    company_name: Optional[str] = None
    udyam_regno: Optional[str] = None
    address: Optional[str] = None
    state: Optional[str] = None
    state_code: Optional[str] = None
    gstin: Optional[str] = None
    email: Optional[str] = None
    mobile: Optional[str] = None
    created_at: Optional[datetime] = None
    updated_at: Optional[datetime] = None
    supplier_name: Optional[str] = None
    supplier_address: Optional[str] = None
    

class InvoiceBuyerDetails(BaseModel):
    invoice_id: int
    buyer_company_name: Optional[str] = None
    buyer_address: Optional[str] = None
    buyer_state: Optional[str] = None
    buyer_state_code: Optional[str] = None
    buyer_gstin: Optional[str] = None
    buyer_pan: Optional[str] = None
    buyer_cin: Optional[str] = None
    created_at: Optional[datetime] = None
    updated_at: Optional[datetime] = None


class InvoiceShippingDetails(BaseModel):
    invoice_id: int
    ship_to_company_name: Optional[str] = None
    ship_to_address: Optional[str] = None
    ship_to_state: Optional[str] = None
    ship_to_state_code: Optional[str] = None
    ship_to_gstin: Optional[str] = None
    ship_to_pan: Optional[str] = None
    ship_to_cin: Optional[str] = None
    created_at: Optional[datetime] = None
    updated_at: Optional[datetime] = None

class InvoiceLineItems(BaseModel):
    # invoice_id: int
    invoice_id: Optional[int] = None
    invoice_number: Optional[str] = None
    item_name: Optional[str] = None
    hsn: Optional[str] = None
    quantity: Optional[float] = None
    uom: Optional[str] = None
    rate_incl_of_tax: Optional[float] = None
    unit_price: Optional[float] = None
    total_retail_price: Optional[float] = None
    discount_value: Optional[float] = None
    total_taxable_amount: Optional[float] = None
    sgst_rate: Optional[float] = None
    sgst_amount: Optional[float] = None
    cgst_rate: Optional[float] = None
    cgst_amount: Optional[float] = None
    igst_rate: Optional[float] = None
    igst_amount: Optional[float] = None
    total_value: Optional[float] = None
    tcs_rate: Optional[float] = None
    taxable_value: Optional[float] = None
    total_cgst_amount: Optional[float] = None
    total_sgst_amount: Optional[float] = None
    total_tax_amount: Optional[float] = None
    total_invoice_value: Optional[float] = None
    material_code: Optional[str] = None
    chassis_number: Optional[str] = None
    engine_number: Optional[str] = None
    # discount: Optional[float] = None
    discount: Optional[float] = 0.0


class InvoiceSummary(BaseModel):
    invoice_id: int
    total_discount_value: Optional[float] = None
    total_quantity: Optional[float] = None
    total_taxable_amount: Optional[float] = None
    tcs_rate: Optional[str] = None
    taxable_value: Optional[float] = None
    total_cgst_amount: Optional[float] = None
    total_sgst_amount: Optional[float] = None
    total_tax_amount: Optional[float] = None
    total_invoice_value: Optional[float] = None
    created_at: Optional[datetime] = None
    updated_at: Optional[datetime] = None

class InvoiceBankDetails(BaseModel):
    invoice_id: int
    account_holder_name: Optional[str] = None
    bank_name: Optional[str] = None
    account_number: Optional[str] = None
    branch_name: Optional[str] = None
    ifsc_code: Optional[str] = None
    created_at: Optional[datetime] = None
    updated_at: Optional[datetime] = None

class InvoiceAssetDetails(BaseModel):
    invoice_id: int
    material_code: Optional[str] = None
    chassis_number: Optional[str] = None
    engine_number: Optional[str] = None

# --- Purchase Order Models ---
class PurchaseOrderDetails(BaseModel):
    po_number: str
    po_date: Optional[date] = None
    total_amount: Optional[float] = None
    vendor_ref: Optional[str] = None
    delivery_terms: Optional[str] = None
    payment_term: Optional[str] = None
    shipment_mode: Optional[str] = None
    warranty_period: Optional[str] = None
    delivery_period: Optional[str] = None
    contact_person: Optional[str] = None
    mobile: Optional[str] = None
    created_at: Optional[datetime] = None
    updated_at: Optional[datetime] = None

class POSupplierDetails(BaseModel):
    po_id: int
    supplier_name: Optional[str] = None
    supplier_code: Optional[str] = None
    gstin_supplier: Optional[str] = None
    supplier_address: Optional[str] = None
    created_at: Optional[datetime] = None
    updated_at: Optional[datetime] = None

class POBillTo(BaseModel):
    po_id: int
    bill_to: Optional[str] = None
    billing_address: Optional[str] = None
    gstin_buyer: Optional[str] = None
    created_at: Optional[datetime] = None
    updated_at: Optional[datetime] = None

class POShippingDetails(BaseModel):
    po_id: int
    ship_to: Optional[str] = None
    shipping_address: Optional[str] = None
    gstin_buyer: Optional[str] = None
    created_at: Optional[datetime] = None
    updated_at: Optional[datetime] = None


class POSummary(BaseModel):
    po_id: int
    total_qty: Optional[float] = None
    total_rate: Optional[float] = None
    total_discount: Optional[float] = None
    total_taxable_amount: Optional[float] = None
    total_gst_amt: Optional[float] = None
    total_billable_value: Optional[float] = None
    charges_and_deductions: Optional[float] = None
    total_purchase_order_amount: Optional[float] = None
    created_at: Optional[datetime] = None
    updated_at: Optional[datetime] = None
    
class POTermsConditions(BaseModel):
    po_id: int
    terms_conditions: Optional[str] = None
    created_at: Optional[datetime] = None
    updated_at: Optional[datetime] = None

class MRNDetails(BaseModel):
    mrn_number: str
    mrn_date: Optional[date]
    po_reference_number: Optional[str]
    po_date: Optional[date]
    ref_invoice_number: Optional[str]
    ref_invoice_date: Optional[date]
    info: Optional[str]
    remarks: Optional[str]
    created_at: Optional[datetime] = None
    updated_at: Optional[datetime] = None

class MRNSupplierDetails(BaseModel):
    mrn_id: int
    supplier_name: Optional[str]
    supplier_address: Optional[str]
    gstin_supplier: Optional[str]
    created_at: Optional[datetime] = None
    updated_at: Optional[datetime] = None

class MRNBuyerDetails(BaseModel):
    mrn_id: int
    received_at: Optional[str]
    received_address: Optional[str]
    gstin_receiving_party: Optional[str]
    created_at: Optional[datetime] = None
    updated_at: Optional[datetime] = None

class MRNLineItems(BaseModel):
    mrn_id: int
    item_name: Optional[str]
    received_quantity: Optional[float]
    hsn_sac: Optional[str]
    uom: Optional[str]
    mrp: Optional[float]
    unit_price: Optional[float]
    discount: Optional[float]
    gross_amount: Optional[float]
    net_amount: Optional[float]
    created_at: Optional[datetime] = None
    updated_at: Optional[datetime] = None

class MRNSummary(BaseModel):
    batch_id: str
    mrn_id: int
    total_qty: Optional[float] = None
    hsn_sac: Optional[str] = None
    gst_rate: Optional[float] = None
    cgst_amount: Optional[float] = None
    sgst_amount: Optional[float] = None
    igst_amount: Optional[float] = None
    cess: Optional[float] = None
    total_gst_amount: Optional[float] = None
    total_gross_amount: Optional[float] = None
    total_discount: Optional[float] = None
    sub_total: Optional[float] = None
    round_off: Optional[float] = None
    total_value: Optional[float] = None

# --- RAO (Receipts Against Order - Asset) Models ---

class RAODetails(BaseModel):
    rao_id: Optional[int]  # Optional for insert; will be auto-generated if SERIAL
    rao_number: Optional[str]
    rao_date: Optional[date]
    po_reference_number: Optional[str]
    po_date: Optional[date]
    ref_invoice_number: Optional[str]
    ref_invoice_date: Optional[date]
    created_at: Optional[datetime] = None
    updated_at: Optional[datetime] = None
    


class RAOSupplierDetails(BaseModel):
    rao_id: int
    supplier_name: Optional[str]
    supplier_address: Optional[str]
    gstin_supplier: Optional[str]
    created_at: Optional[datetime] = None
    updated_at: Optional[datetime] = None

class RAOBuyerDetails(BaseModel):
    rao_id: int
    received_date: date
    received_at: Optional[str]
    received_address: Optional[str]
    gstin_receiving_party: Optional[str]
    created_at: Optional[datetime] = None
    updated_at: Optional[datetime] = None
    

class RAOLineItems(BaseModel):
    rao_id: int
    item_name: Optional[str]
    received_quantity: Optional[float]
    hsn_sac: Optional[str]
    unit_price: Optional[float]
    discount: Optional[float]
    gst_rate: Optional[float]
    total_value: Optional[float]
    engine_no: Optional[str]
    chasis_no: Optional[str]
    serial_no: Optional[str]
    asset_id: Optional[str]
    total_value: Optional[float]
    created_at: Optional[datetime] = None
    updated_at: Optional[datetime] = None

class RAOSummary(BaseModel):
    rao_id: int
    total_discount: Optional[float]
    cgst: float
    sgst: float
    igst: float
    gst_amount: float
    gross_amount: float
    sub_total: float
    cess: float
    total_qty: float
    total_value: float
    created_at: Optional[datetime] = None
    updated_at: Optional[datetime] = None
    
class POOrderDetails(BaseModel):
    supplier_name: Optional[str] = None
    po_number: Optional[str] = None
    po_date: Optional[str] = None
    total_amount: Optional[float] = None
    gstin_supplier: Optional[str] = None
    bill_to: Optional[str] = None
    billing_address: Optional[str] = None
    ship_to: Optional[str] = None
    shipping_address: Optional[str] = None
    gstin_buyer: Optional[str] = None
    document_title: Optional[str] = None
    batch_id: Optional[str] = None


class POLineItems(BaseModel):
    po_id: int
    po_number: Optional[str] = None
    item_name: Optional[str] = None
    oem_part_code: Optional[str] = None
    quantity: Optional[float] = None
    uom: Optional[str] = None
    unit_price: Optional[float] = None
    discount: Optional[float] = None
    taxable: Optional[float] = None
    gst_rate: Optional[float] = None
    gst_amount: Optional[float] = None
    billable_value: Optional[float] = None
    total_qty: Optional[float] = None
    
    
class InvoicePOMatchResult(BaseModel):
    inv_id: Optional[int]
    po_id: Optional[int]
    invoice_item: Optional[str]
    po_item: Optional[str]
    item_name_match_percent: Optional[float]
    invoice_qty: Optional[float]
    po_qty: Optional[float]
    quantity_match_percent: Optional[float]
    total_taxable_amount: Optional[float]
    po_unit_price: Optional[float]
    unit_price_match_percent: Optional[float]
    invoice_total_value: Optional[float]
    po_total_value: Optional[float]
    total_value_match_percent: Optional[float]
    match_status: str
    mismatch_reason:str
    
class InvoicePOSummary(BaseModel):
    invoice_number: Optional[str]
    po_ref: Optional[str]
    po_number: Optional[str]
    invoice_amount: Optional[float]
    po_amount: Optional[float]
    amount_match_percentage: Optional[float]
    po_number_match: Optional[str]
    

class ThreeWayMatchRecord(BaseModel):
    item_name: str
    item_description_check: Optional[str]
    hsn_code_check: Optional[str]
    quantity_check: Optional[str]
    uom_check: Optional[str]
    unit_price_check: Optional[str]
    gst_rate_check: Optional[str]
    tax_amount_check: Optional[str]
    total_amount_check: Optional[str]
    supplier_gstin_check: Optional[str]
    buyer_gstin_check: Optional[str]
    invoice_number_check: Optional[str]
    po_number_check: Optional[str]
    date_timeline_check: Optional[str]
    delivery_location_check: Optional[str]
    transport_details_check: Optional[str]  
    mrn_number_date_check: Optional[str]
    

class CombinedSummary(BaseModel):
    po_number: Optional[str]
    invoice_id: int
    invoice_number: Optional[str]
    mrn_number: Optional[str]

    po_total_qty: Optional[float]
    po_total_rate: Optional[float]
    po_total_discount: Optional[float]
    po_taxable: Optional[float]
    po_total_gst: Optional[float]
    po_total_billable: Optional[float]
    po_total_value: Optional[float]

    invoice_total_discount: Optional[float]
    invoice_total_qty: Optional[float]
    invoice_taxable: Optional[float]
    invoice_cgst: Optional[float]
    invoice_sgst: Optional[float]
    invoice_total_tax: Optional[float]
    invoice_total_value: Optional[float]

    mrn_total_qty: Optional[float]
    mrn_cgst: Optional[float]
    mrn_sgst: Optional[float]
    mrn_igst: Optional[float]
    mrn_total_gst: Optional[float]
    mrn_total_value: Optional[float]
    
    
    
class InvoiceData(BaseModel):
    invoice_details: InvoiceDetailsAndSummary
    line_items: List[InvoiceLineItems]
    
    
    
class InvoiceChecklist(BaseModel):
    invoice_id: int
    invoice_no: str
    invoice_no_duplicate: str
    invoice_date: Optional[date]  # changed from str to date
    po_date: Optional[date]       # changed from str to date
    invoice_total: Optional[float]
    invoice_total_lineitems: Optional[float]
    invoice_total_values_lineitems: Optional[str]
    invoice_total_check: Optional[str]
    vendor_name: Optional[str]
    vendor_name_master: Optional[str]
    vendorname_check: Optional[str]
    supplier_gstin: Optional[str]
    suppler_gstin_po: Optional[str]
    supplier_gstin_check: Optional[str]
    buyer_gstin: Optional[str]
    buyer_gstin_po: Optional[str]
    buyer_gstin_check: Optional[str]
    supplier_pan: Optional[str]
    supplier_pan_master: Optional[str]
    suplier_pan_check: Optional[str]
    supplier_gstin_pan_check: Optional[str]
    gstin_master: Optional[str]
    gstin_invoice_master_check: Optional[str]