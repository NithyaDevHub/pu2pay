import os
import cv2
import json
import streamlit as st
import pandas as pd
from paddleocr import PaddleOCR
from PIL import Image
from langchain.llms import Ollama
from langchain_core.prompts import PromptTemplate
from langchain_core.output_parsers import StrOutputParser
import re

# Initialize once
ocr_model = PaddleOCR(use_angle_cls=True, lang='en')
llm = Ollama(model="llama3.1:latest")

# LangChain prompt for LLM
prompt_template = PromptTemplate(
    input_variables=["ocr_text"],
    template="""
You are an AI that extracts structured data from OCR invoice content.

Here is the OCR text from the invoice:
{ocr_text}

Extract the following:
1. Invoice Number
2. Invoice Date
3. Supplier Name
4. Buyer Name
5. Total Amount
6. Each line item with description, quantity, unit price, total price

Return only valid JSON with out any extra explanation:
{{
  "invoice_number": "...",
  "invoice_date": "...",
  "supplier_name": "...",
  "buyer_name": "...",
  "total_amount": "...",
  "line_items": [
    {{
      "description": "...",
      "quantity": "...",
      "unit_price": "...",
      "total_price": "..."
    }},
    ...
  ]
}}
"""
)
llm_chain = prompt_template | llm | StrOutputParser()

def extract_text_from_image(image_path):
    result = ocr_model.ocr(image_path, cls=True)
    return "\n".join([line[1][0] for line in result[0]])

def is_image_file(file_path):
    return file_path.lower().endswith(('.png', '.jpg', '.jpeg', '.bmp', '.tiff', '.webp'))


def clean_json_response(response_text):
    # Remove markdown code block markers if present
    response_text = response_text.strip()
    if response_text.startswith("```"):
        response_text = re.sub(r"^```[a-zA-Z]*\n?", "", response_text)
        response_text = response_text.rstrip("```").strip()
    return response_text

# Streamlit UI
st.title("📁 Batch Invoice Extractor (Folder Input)")

folder_path = st.text_input("Enter full path to folder containing invoice images")

if folder_path and os.path.isdir(folder_path):
    invoice_records = []
    line_items = []

    image_files = [f for f in os.listdir(folder_path) if is_image_file(f)]

    if not image_files:
        st.warning("No valid image files found in the folder.")
    else:
        for filename in image_files:
            file_path = os.path.join(folder_path, filename)
            st.image(file_path, caption=filename)

            ocr_text = extract_text_from_image(file_path)

            try:
                llm_response = llm_chain.invoke({"ocr_text": ocr_text})
                print(f"LLM Response for {filename}: {llm_response}")
                cleaned_response = clean_json_response(llm_response)
                data = json.loads(cleaned_response)  # safer than eval
                invoice_records.append({
                    "Invoice Number": data["invoice_number"],
                    "Invoice Date": data["invoice_date"],
                    "Supplier": data["supplier_name"],
                    "Buyer": data["buyer_name"],
                    "Total Amount": data["total_amount"]
                })

                for item in data["line_items"]:
                    item["Invoice Number"] = data["invoice_number"]
                    line_items.append(item)

            except Exception as e:
                st.error(f"Failed to parse invoice {filename}: {e}")

        if invoice_records:
            invoice_df = pd.DataFrame(invoice_records)
            line_item_df = pd.DataFrame(line_items)

            with pd.ExcelWriter("invoice_extracted.xlsx", engine="openpyxl") as writer:
                invoice_df.to_excel(writer, sheet_name="Invoice_Details", index=False)
                line_item_df.to_excel(writer, sheet_name="Line_Items", index=False)

            st.success("✅ Extraction completed. Download below:")
            with open("invoice_extracted.xlsx", "rb") as f:
                st.download_button("📥 Download Excel", f, file_name="invoice_extracted.xlsx")

else:
    st.info("Please provide a valid folder path containing invoice images.")
