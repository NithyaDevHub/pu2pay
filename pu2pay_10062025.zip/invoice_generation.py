import pandas as pd
import random
import string

# Load your CSV file
df = pd.read_csv("/Users/fis/Documents/pu2pay/vpr_po.csv")  # Replace with your CSV file path

# Function to generate random invoice numbers
def generate_invoice_number(prefix="INV", length=6):
    return f"{prefix}{''.join(random.choices(string.digits, k=length))}"

# Add a new column with random invoice numbers
df['InvoiceNumber'] = [generate_invoice_number() for _ in range(len(df))]

# Save to a new CSV file (or overwrite original)
df.to_csv("output_with_invoices.csv", index=False)

print("Invoice numbers added successfully.")
