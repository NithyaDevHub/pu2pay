from pydantic import BaseModel, Field
from typing import List, Optional



class LineItem(BaseModel):
    item_name: str
    hsn: Optional[str]
    item_qty: str
    uom: Optional[str]
    rate_incl_of_tax: str
    unit_price: str
    total_retail_price: str
    total_taxable_amount: str
    discount: str
    total_value: str

class Invoice(BaseModel):
    invoice_number: str
    invoice_date: str
    total_amount: str
    po_ref: Optional[str] = ""
    company_name: Optional[str] = ""
    supplier_name: Optional[str] = ""
    supplier_address: Optional[str] = ""
    bill_to_company_name: Optional[str] = ""
    bill_to_address: Optional[str] = ""
    bill_to_state: Optional[str] = ""
    bill_to_state_code: Optional[str] = ""
    bill_to_pan: Optional[str] = ""
    bill_to_cin: Optional[str] = ""
    ship_to_company_name: Optional[str] = ""
    ship_to_address: Optional[str] = ""
    ship_to_state: Optional[str] = ""
    ship_to_state_code: Optional[str] = ""
    ship_to_gstin: Optional[str] = ""
    ship_to_pan: Optional[str] = ""
    ship_to_cin: Optional[str] = ""
    pan_supplier: Optional[str] = ""
    gstin_supplier: Optional[str] = ""
    bill_to_gstin: Optional[str] = ""
    udyam_regno: Optional[str] = ""
    state: Optional[str] = ""
    state_code: Optional[str] = ""
    invoice_id: Optional[str] = ""
    discount: Optional[str] = "0"
    Qty: Optional[str] = "0"
    total_taxable_amount: Optional[str] = "0"
    total_discount_value: Optional[str] = "0"
    total_quantity: Optional[str] = "0"
    taxable_value: Optional[str] = "0"
    tcs_rate: Optional[str] = "0"
    total_cgst_amount: Optional[str] = "0"
    total_sgst_amount: Optional[str] = "0"
    total_tax_amount: Optional[str] = "0"
    total_invoice_value: Optional[str] = "0"
    line_items: List[LineItem]