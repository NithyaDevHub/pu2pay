# --------------------------------------------
# 🧠 Document Comparison Script (macOS + MPS)
# --------------------------------------------

# ✅ INSTALL DEPENDENCIES IN TERMINAL:
# pip install paddleocr==2.6.1.3
# pip install paddlepaddle==2.5.1 -f https://www.paddlepaddle.org.cn/whl/macos/mps.html
# pip install opencv-python matplotlib pillow pandas

import os
import cv2
import json
import pandas as pd
import matplotlib.pyplot as plt
from PIL import Image, ImageDraw
from paddleocr import PaddleOCR

# ✅ Initialize PaddleOCR (macOS MPS)
ocr = PaddleOCR(use_textline_orientation=True, lang='en')

# ✅ Run OCR and optionally save results
def run_ocr_and_save(image_path, save_json=True):
    image = Image.open(image_path).convert("RGB")
    result = ocr.ocr(image_path)[0]
    text_data = [line[1][0] for line in result if len(line) == 2]

    if save_json:
        json_path = image_path.replace(".png", "_ocr.json").replace(".jpg", "_ocr.json")
        with open(json_path, "w") as f:
            json.dump(text_data, f, indent=2)

    return set(t.lower() for t in text_data), image, result

# ✅ Compare two OCR result sets
def compare_texts(set1, set2):
    return sorted(set1 - set2), sorted(set2 - set1)

# ✅ Show pixel difference heatmap
def show_pixel_difference(img1_path, img2_path):
    if not os.path.exists(img1_path):
        print(f"❌ Missing image: {img1_path}")
    if not os.path.exists(img2_path):
        print(f"❌ Missing image: {img2_path}")

    img1 = cv2.imread(img1_path)
    img2 = cv2.imread(img2_path)

    if img1 is None or img2 is None:
        raise FileNotFoundError(f"Could not read one or both images:\n{img1_path}\n{img2_path}")

    img1 = cv2.resize(img1, (512, 512))
    img2 = cv2.resize(img2, (512, 512))
    diff = cv2.absdiff(img1, img2)
    diff_gray = cv2.cvtColor(diff, cv2.COLOR_BGR2GRAY)

    fig, axs = plt.subplots(1, 3, figsize=(18, 6))
    axs[0].imshow(cv2.cvtColor(img1, cv2.COLOR_BGR2RGB))
    axs[0].set_title("Document 1")
    axs[0].axis('off')

    axs[1].imshow(cv2.cvtColor(img2, cv2.COLOR_BGR2RGB))
    axs[1].set_title("Document 2")
    axs[1].axis('off')

    axs[2].imshow(diff_gray, cmap='hot')
    axs[2].set_title("Pixel-Level Difference")
    axs[2].axis('off')

    plt.tight_layout()
    plt.show()

# ✅ Visualize semantic text difference with bounding boxes
def visualize_text_diff(doc1_path, doc2_path, only_in_1, only_in_2):
    _, img1, result1 = run_ocr_and_save(doc1_path, save_json=False)
    _, img2, result2 = run_ocr_and_save(doc2_path, save_json=False)

    img1_draw = img1.copy()
    draw1 = ImageDraw.Draw(img1_draw)
    for line in result1:
        text = line[1][0].lower()
        if text in only_in_1:
            box = line[0]
            draw1.polygon([tuple(p) for p in box], outline="red", width=3)

    img2_draw = img2.copy()
    draw2 = ImageDraw.Draw(img2_draw)
    for line in result2:
        text = line[1][0].lower()
        if text in only_in_2:
            box = line[0]
            draw2.polygon([tuple(p) for p in box], outline="green", width=3)

    fig, axs = plt.subplots(1, 2, figsize=(18, 10))
    axs[0].imshow(img1_draw)
    axs[0].set_title("Only in Document 1 (Red Boxes)")
    axs[0].axis("off")

    axs[1].imshow(img2_draw)
    axs[1].set_title("Only in Document 2 (Green Boxes)")
    axs[1].axis("off")

    plt.tight_layout()
    plt.show()

# ✅ Batch folder comparison (optional)
def batch_compare(folder1, folder2):
    results = []
    for fname in os.listdir(folder1):
        if fname.lower().endswith(('.png', '.jpg')) and fname in os.listdir(folder2):
            f1 = os.path.join(folder1, fname)
            f2 = os.path.join(folder2, fname)

            set1, _, _ = run_ocr_and_save(f1, save_json=True)
            set2, _, _ = run_ocr_and_save(f2, save_json=True)

            only1, only2 = compare_texts(set1, set2)
            results.append({
                "filename": fname,
                "only_in_doc1": only1,
                "only_in_doc2": only2
            })

    df = pd.DataFrame(results)
    df.to_csv("comparison_summary.csv", index=False)
    print("✅ Saved: comparison_summary.csv")
    return df

# --------------------------------------------
# ✅ USAGE EXAMPLE: Replace with your paths
# --------------------------------------------

doc1 = "/Users/fis/Documents/pu2pay/testimages/testinvoice.png"
doc2 = "/Users/fis/Documents/pu2pay/testimages/testinvoice_wrongGSTIN.jpg"

# 🔍 Step 1: Run pixel-level comparison
show_pixel_difference(doc1, doc2)

# 🔍 Step 2: Run OCR + semantic comparison
set1, _, _ = run_ocr_and_save(doc1)
set2, _, _ = run_ocr_and_save(doc2)
only1, only2 = compare_texts(set1, set2)

print("\n🔴 Only in Document 1:\n", only1)
print("\n🟢 Only in Document 2:\n", only2)

# 🔍 Step 3: Visualize text difference boxes
visualize_text_diff(doc1, doc2, only1, only2)

# 🔁 Optional: Folder comparison (Uncomment to use)
# batch_compare("/path/to/folder1", "/path/to/folder2")
