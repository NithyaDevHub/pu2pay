import json
from paddleocr import PaddleOCR
from langchain_core.prompts import PromptTemplate
from langchain_community.llms import Ollama

# Initialize PaddleOCR
ocr = PaddleOCR(use_angle_cls=True, lang='en')

# OCR extraction function
def extract_text(image_path):
    result = ocr.ocr(image_path, cls=True)
    if result and isinstance(result[0], list):
        return " ".join([line[1][0] for line in result[0]])
    return ""

# Initialize Ollama LLM via LangChain
llm = Ollama(model="llama3.1:latest", temperature=0)

# Prompt template
prompt_template = """
You are an intelligent invoice parser. Extract the following fields from the given text and return the result in valid JSON format. Ensure nested objects like line_items are arrays of dictionaries.

Extract these fields under details:
- invoice_number
- invoice_date
- total_amount
- po_ref
- company_name
- buyer_company_name
- buyer_address
- buyer_state
- buyer_state_code
- buyer_pan
- buyer_cin
- ship_to_company_name (may appear under labels like "Ship To", "Consignee", or "Deliver To" or "Delivery Address".)
- ship_to_address
- ship_to_state
- ship_to_state_code
- ship_to_gstin
- ship_to_pan
- ship_to_cin
- pan_supplier
- gstin_supplier
- buyer_gstin
- udyam_regno
- state
- state_code
- supplier_name (if not labeled, assume it is the first visible text block at the top of the invoice before other fields like 'Invoice Number' or 'Bill To')
- invoice_id
- discount
- Qty
- total_taxable_amount
- total_discount_value
- total_quantity
- taxable_value
- tcs_rate
- total_cgst_amount
- total_sgst_amount
- total_tax_amount
- total_invoice_value

Also extract the following as a list of line items (under line_items):
- item_name
- hsn
- item_qty
- uom
- rate_incl_of_tax
- unit_price
- total_retail_price
- total_taxable_amount
- discount
- total_value

Return only the JSON object without any explanation or commentary.

Invoice Text:
{invoice_text}
"""

# Process image with OCR → Ollama
def process_invoice_image(image_path):
    print(f"🔍 Running OCR on: {image_path}")
    ocr_text = extract_text(image_path)
    
    # print(f"extracted text: ---------------------------- {ocr_text}")

    if not ocr_text:
        print("❌ No text found in image.")
        return

    print("🧠 Sending text to LLaMA3.1 for structured extraction...")

    final_prompt = prompt_template.format(invoice_text=ocr_text)
    response = llm.invoke(final_prompt)

    try:
        parsed_json = json.loads(response)
        print("✅ Extracted JSON:\n")
        print(json.dumps(parsed_json, indent=2))
    except json.JSONDecodeError:
        print("⚠️ Could not parse response as JSON. Raw output:")
        print(response)

# Example usage
# if __name__ == "__main__":
#     image_path = "sample_invoice.png"  # replace with your image path
#     process_invoice_image(image_path)

# Example usage
if __name__ == "__main__":
    image_path = r"/Users/fis/Documents/pu2pay/hypotus_images/PV 205 Date 10-01-2025 SK Broadband Service_2.png"
    process_invoice_image(image_path)
