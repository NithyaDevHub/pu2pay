import json
import re
from typing import List, Optional
from pydantic import BaseModel, Field, field_validator
from paddleocr import PaddleOCR
from langchain_core.prompts import PromptTemplate
from langchain_community.llms import Ollama
from datetime import datetime


# ---------------------- Pydantic Model ----------------------
def extract_first_date(text):
    match = re.search(r"\b(\d{2}[/-]\d{2}[/-]\d{4})\b", text)
    return match.group(1) if match else None
# def extract_first_date(text):
#     match = re.search(r"\b(\d{2}[/-]\d{2}[/-]\d{4}|\d{4}[/-]\d{2}[/-]\d{2})\b", text)
#     return match.group(1) if match else None


def extract_total_amount(text):
    match = re.search(r"total\s+amount[:\s]*₹?\s?([\d,]+\.\d{2})", text, re.IGNORECASE)
    if match:
        return float(match.group(1).replace(',', ''))
    return None



class LineItem(BaseModel):
    item_name: Optional[str]
    hsn: Optional[str]
    item_qty: Optional[float]
    uom: Optional[str]
    rate_incl_of_tax: Optional[float]
    unit_price: Optional[float]
    total_retail_price: Optional[float]
    total_taxable_amount: Optional[float]
    discount: Optional[float]
    total_value: Optional[float]


class InvoiceData(BaseModel):
    invoice_number: Optional[str]
    invoice_date: Optional[str]  # Will be coerced to date in validator
    total_amount: Optional[float]
    po_ref: Optional[str]
    company_name: Optional[str]
    buyer_company_name: Optional[str]
    buyer_address: Optional[str]
    buyer_state: Optional[str]
    buyer_state_code: Optional[str]
    buyer_pan: Optional[str]
    buyer_cin: Optional[str]
    ship_to_company_name: Optional[str]
    ship_to_address: Optional[str]
    ship_to_state: Optional[str]
    ship_to_state_code: Optional[str]
    ship_to_gstin: Optional[str]
    ship_to_pan: Optional[str]
    ship_to_cin: Optional[str]
    pan_supplier: Optional[str]
    gstin_supplier: Optional[str]
    buyer_gstin: Optional[str]
    udyam_regno: Optional[str]
    state: Optional[str]
    state_code: Optional[str]
    supplier_name: Optional[str]
    supplier_address: Optional[str]
    invoice_id: Optional[str]
    discount: Optional[float]
    Qty: Optional[float]
    total_taxable_amount: Optional[float]
    total_discount_value: Optional[float]
    total_quantity: Optional[float]
    taxable_value: Optional[float]
    tcs_rate: Optional[float]
    total_cgst_amount: Optional[float]
    total_sgst_amount: Optional[float]
    total_tax_amount: Optional[float]
    total_invoice_value: Optional[float]
    line_items: List[LineItem] = Field(default_factory=list)

    # @field_validator(mode="before")
    # def clean_fields(cls, values):
    #     def parse_amount(v):
    #         if isinstance(v, str):
    #             try:
    #                 return float(v.replace(",", "").replace("₹", "").strip())
    #             except:
    #                 return None
    #         elif isinstance(v, (int, float)):
    #             return float(v)
    #         return None

    #     # Normalize invoice date
    #     if isinstance(values.get("invoice_date"), str):
    #         try:
    #             values["invoice_date"] = datetime.strptime(values["invoice_date"], "%d/%m/%Y").date()
    #         except ValueError:
    #             pass

    #     # Fields to parse as amounts
    #     for key in [
    #         "total_amount", "discount", "Qty", "total_taxable_amount", "total_discount_value",
    #         "total_quantity", "taxable_value", "tcs_rate", "total_cgst_amount", "total_sgst_amount",
    #         "total_tax_amount", "total_invoice_value"
    #     ]:
    #         if key in values:
    #             values[key] = parse_amount(values[key])

    #     # Normalize line_items if present
    #     if "line_items" in values:
    #         for item in values["line_items"]:
    #             for k in [
    #                 "item_qty", "rate_incl_of_tax", "unit_price", "total_retail_price",
    #                 "total_taxable_amount", "discount", "total_value"
    #             ]:
    #                 if k in item:
    #                     item[k] = parse_amount(item[k])

    #     return values




class LineItem(BaseModel):
    item_name: Optional[str]
    hsn: Optional[str]
    item_qty: Optional[float]
    uom: Optional[str]
    rate_incl_of_tax: Optional[float]
    unit_price: Optional[float]
    total_retail_price: Optional[float]
    total_taxable_amount: Optional[float]
    discount: Optional[float]
    total_value: Optional[float]
    
    
    @field_validator("item_qty", mode="before")
    @classmethod
    def coerce_quantity(cls, v):
        try:
            return float(v)
        except:
            return None

    
    @field_validator(
        "rate_incl_of_tax", "unit_price", "total_retail_price",
        "total_taxable_amount", "discount", "total_value",
        mode="before")
    @classmethod
    def clean_line_amount_fields(cls, v):
        return cls._parse_amount(v)
    
    
    @field_validator("hsn", mode="before")
    @classmethod
    def validate_hsn(cls, v):
        if v and not re.match(r"^\d{4,8}$", v):
            print("⚠️ Invalid HSN code:", v)
        return v


    @staticmethod
    def _parse_amount(value):
        if isinstance(value, str):
            cleaned = value.replace(",", "").replace("₹", "").strip()
            try:
                return float(cleaned)
            except ValueError:
                return None
        elif isinstance(value, (int, float)):
            return float(value)
        return None


class InvoiceData(BaseModel):
    invoice_number: Optional[str]
    invoice_date: Optional[str]
    total_amount: Optional[float]
    po_ref: Optional[str]
    company_name: Optional[str]
    buyer_company_name: Optional[str]
    buyer_address: Optional[str] = None
    buyer_state: Optional[str]
    buyer_state_code: Optional[str] = None
    buyer_pan: Optional[str] = None
    buyer_cin: Optional[str]
    ship_to_company_name: Optional[str]
    ship_to_address: Optional[str]
    ship_to_state: Optional[str]
    ship_to_state_code: Optional[str]
    ship_to_gstin: Optional[str]
    ship_to_pan: Optional[str]
    ship_to_cin: Optional[str]
    pan_supplier: Optional[str]
    gstin_supplier: Optional[str]
    buyer_gstin: Optional[str]
    udyam_regno: Optional[str] = None
    state: Optional[str]
    state_code: Optional[str]
    supplier_name: Optional[str]
    supplier_address: Optional[str] = None
    invoice_id: Optional[str]
    discount: Optional[float]
    Qty: Optional[float]
    total_taxable_amount: Optional[float]
    total_discount_value: Optional[float]
    total_quantity: Optional[float]
    taxable_value: Optional[float]
    tcs_rate: Optional[float]
    total_cgst_amount: Optional[float]
    total_sgst_amount: Optional[float]
    total_tax_amount: Optional[float]
    total_invoice_value: Optional[float]
    line_items: Optional[List[LineItem]] = Field(default_factory=list)
    # ocr_text: Optional[str] = None  # For fallback use

    @field_validator("*", mode="before")
    @classmethod
    def strip_text(cls, v):
        if isinstance(v, str):
            return v.strip()
        return v
    
    @field_validator("Qty", "total_quantity", mode="before")
    @classmethod
    def coerce_quantity(cls, v):
        try:
            return float(v)
        except:
            return None
    
    
    @field_validator(
    "total_amount", "total_tax_amount", "total_invoice_value",
    "total_cgst_amount", "total_sgst_amount", "total_discount_value",
    "taxable_value",
    "tcs_rate", mode="before"
    )
    @classmethod
    def clean_amount_fields(cls, v):
        return cls._parse_amount(v)
    
    @staticmethod
    def _parse_amount(value):
        if isinstance(value, str):
            cleaned = value.replace(",", "").replace("₹", "").strip()
            try:
                return float(cleaned)
            except ValueError:
                return None
        elif isinstance(value, (int, float)):
            return float(value)
        return None


    @field_validator("supplier_name", mode="before")
    @classmethod
    def fallback_supplier(cls, v, values):
        if v:
            return v
        ocr_text = values.get("ocr_text", "")
        for line in ocr_text.splitlines():
            if line.strip() and "invoice" not in line.lower():
                return line.strip()
        return None


    @field_validator("ship_to_company_name", mode="before")
    @classmethod
    def fallback_ship_to(cls, v, values):
        if v:
            return v
        ocr_text = values.data.get("ocr_text", "")
        lines = ocr_text.splitlines()
        for i, line in enumerate(lines):
            if "ship to" in line.lower() and i + 1 < len(lines):
                return lines[i + 1].strip()
        return None
    
    
    @field_validator("buyer_pan", "pan_supplier", mode="before")
    @classmethod
    def validate_pan(cls, v):
        if v and isinstance(v, str) and not re.match(r"^[A-Z]{5}[0-9]{4}[A-Z]$", v.upper()):
            print("⚠️ Invalid PAN format:", v)
        return v
    
    @field_validator("gstin_supplier", mode="before")
    def extract_actual_value(field: Optional[str], prefix: str) -> Optional[str]:
        if field and isinstance(field, str) and prefix.lower() in field.lower():
            return field.split(":")[-1].strip()
        return field

    
    @field_validator("gstin_supplier", "buyer_gstin", "ship_to_gstin", mode="before")
    @classmethod
    def validate_gstin(cls, v):
        if v and not re.match(r"^[0-9]{2}[A-Z]{5}[0-9]{4}[A-Z]{1}[1-9A-Z]{1}Z[0-9A-Z]{1}$", v.upper()):
            print("⚠️ Invalid GSTIN:", v)
        return v



    @field_validator("buyer_company_name", mode="before")
    @classmethod
    def fallback_buyer_company(cls, v, values):
        if v:
            return v
        ocr_text = values.data.get("ocr_text", "")
        lines = ocr_text.splitlines()
        for i, line in enumerate(lines):
            if "billed to" in line.lower() and i + 1 < len(lines):
                return lines[i + 1].strip()
        return None

    @field_validator("invoice_date", mode="before")
    @classmethod
    def fallback_invoice_date(cls, v, values):
        return v or extract_first_date(values.data.get("ocr_text", ""))


    @field_validator("total_amount", mode="before")
    @classmethod
    def fallback_total_amount(cls, v, values):
        if v:
            return cls._parse_amount(v)
        return extract_total_amount(values.data.get("ocr_text", ""))


# ---------------------- OCR and LLM Integration ----------------------
ocr = PaddleOCR(use_angle_cls=True, lang='en')
llm = Ollama(model="llama3.1:latest", temperature=0)

def extract_text(image_path):
    result = ocr.ocr(image_path, cls=True)
    if result and isinstance(result[0], list):
        return "\n".join([line[1][0] for line in result[0]])
    return ""

prompt_template = """
You are an intelligent invoice parser. Extract the following fields from the given text and return the result in valid JSON format. Ensure nested objects like line_items are arrays of dictionaries.

Extract the below fields:
- invoice_number
- invoice_date
- total_amount
- po_ref (if not present, leave null)
- company_name
- buyer_company_name
- buyer_address
- buyer_state
- buyer_state_code
- buyer_pan
- buyer_cin
- ship_to_company_name (may appear under labels like "Ship To", "Consignee", or "Deliver To" or "Delivery Address".)
- ship_to_address
- ship_to_state
- ship_to_state_code
- ship_to_gstin
- ship_to_pan
- ship_to_cin
- pan_supplier
- gstin_supplier
- buyer_gstin
- udyam_regno
- state
- state_code
- supplier_name (if not labeled, assume it is the first visible text block at the top of the invoice before other fields like 'Invoice Number' or 'Bill To')
- invoice_id
- discount
- Qty
- total_taxable_amount
- total_discount_value
- total_quantity
- taxable_value
- tcs_rate
- total_cgst_amount
- total_sgst_amount
- total_tax_amount
- total_invoice_value

Also extract the following as a list of line items (under line_items):
- item_name
- hsn
- item_qty
- uom
- rate_incl_of_tax
- unit_price
- total_retail_price
- total_taxable_amount
- discount
- total_value

Return only the JSON object without any explanation or commentary.

Invoice Text:
{invoice_text}
"""


def extract_clean_json(text):
    # Step 1: Remove markdown fence if present
    match = re.search(r"```json\s*(\{.*?\})\s*```", text, re.DOTALL)
    if match:
        text = match.group(1)

    # Step 2: Clean and validate json part
    try:
        raw = json.loads(text)
        if "details" in raw and "line_items" in raw:
            # Flatten details and line_items
            return {**raw["details"], "line_items": raw["line_items"]}
        return raw
    except json.JSONDecodeError:
        raise ValueError("LLM did not return valid JSON.")
    
def process_invoice_image(image_path):
    print(f"🔍 Running OCR on: {image_path}")
    ocr_text = extract_text(image_path)

    if not ocr_text:
        print("❌ No text found in image.")
        return

    print("🧠 Sending text to LLaMA3.1:latest for structured extraction...")
    final_prompt = prompt_template.format(invoice_text=ocr_text)
    response = llm.invoke(final_prompt)

    # print("LLM response:", response)
    # print("🧠 Parsing LLM response...")

    try:
        clean_json = extract_clean_json(response)
        # print(f"clean_json:  ------------ {clean_json}")
        # print("✅ Extracted JSON:\n")
        # print(json.dumps(clean_json, indent=2))
        invoice_data = InvoiceData(**clean_json)
        final_data = invoice_data.model_dump(exclude_none=True)
        print("✅ Validated & Extracted Invoice Data:\n")
        # return json.dumps(clean_json, indent=2)
        return final_data
    except Exception as e:
        print("❌ Parsing failed:", str(e))
        print("🔁 Raw LLM response:\n", response)

# Example usage
if __name__ == "__main__":
    image_path = r"/Users/fis/Documents/pu2pay/hypotus_images/APAR 3 Date 10.09.2024 - Innovative Infra & Mining Solutions Limited (BB Tippets)_7.png"
    process_invoice_image(image_path)
