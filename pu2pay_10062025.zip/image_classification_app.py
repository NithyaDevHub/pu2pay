from paddleocr import PaddleOCR
from PIL import Image
import os
import streamlit as st
import shutil

# Initialize OCR model
ocr_model = PaddleOCR(use_angle_cls=True, lang='en')

# Exact match phrases for "others"
others_exact_matches = [
    "purchase against receipts (asset)",
    "purchase against orders",
    "purchase voucher against receipts",
    "purchase voucher",
    "purchase voucher against orders"
]

# Check if file is an image
def is_image_file(path):
    return path.lower().endswith(('.png', '.jpg', '.jpeg', '.bmp', '.tiff', '.webp'))

# Extract OCR text from top half only
def extract_top_half_text(image_path):
    image = Image.open(image_path)
    height = image.height
    top_half_lines = []

    result = ocr_model.ocr(image_path, cls=True)
    for line in result[0]:
        box, (text, conf) = line
        avg_y = (box[0][1] + box[2][1]) / 2  # average Y position
        if avg_y <= height / 2:
            top_half_lines.append(text.lower().strip())

    return top_half_lines

# Classification logic (only on top half lines)
def classify_from_lines(lines):
    for line in lines:
        if line in others_exact_matches:
            return "others", line

    for line in lines:
        if "purchase order" in line:
            return "po", "purchase order"
        if "e-way bill" in line:
            return "ewaybill", "e-way bill"
        if "invoice" in line:
            return "invoice", "invoice"

    return "unknown", None

# Streamlit UI
st.title("📄 Header-Based Document Classifier (Top-Half Matching)")
input_folder = st.text_input("📁 Input folder path (images only):")
output_folder = st.text_input("📤 Output folder path (classified):")

if st.button("🚀 Start Classification"):
    if not os.path.isdir(input_folder):
        st.error("❌ Invalid input folder path.")
    elif not os.path.isdir(output_folder):
        st.error("❌ Invalid output folder path.")
    else:
        files = [f for f in os.listdir(input_folder) if is_image_file(f)]
        total = len(files)

        if total == 0:
            st.warning("⚠️ No image files found.")
        else:
            st.info(f"🔍 Processing {total} file(s)...")
            progress_bar = st.progress(0)
            status = st.empty()
            label_counts = {}

            for idx, filename in enumerate(files):
                file_path = os.path.join(input_folder, filename)

                lines = extract_top_half_text(file_path)
                label, matched_keyword = classify_from_lines(lines)

                label_counts[label] = label_counts.get(label, 0) + 1
                dest_folder = os.path.join(output_folder, label)
                os.makedirs(dest_folder, exist_ok=True)
                shutil.copy(file_path, os.path.join(dest_folder, filename))

                progress_bar.progress((idx + 1) / total)
                status.text(f"✅ {filename} → {label.upper()} (matched: '{matched_keyword}')")

            st.success("🎉 Classification completed.")

            st.subheader("📊 Classification Summary")
            for label, count in label_counts.items():
                st.write(f"• **{label}**: {count} file(s)")
