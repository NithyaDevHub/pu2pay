import streamlit as st
from streamlit_drawable_canvas import st_canvas
from PIL import Image
import numpy as np
import json
from paddleocr import PaddleOCR

# Init PaddleOCR
ocr = PaddleOCR(use_angle_cls=True, lang='en')

st.set_page_config(layout="wide")
st.title("🖍️ OCR Text Labeling Tool")

# Upload image
uploaded_file = st.file_uploader("Upload an image", type=["png", "jpg", "jpeg"])
if uploaded_file:
    image = Image.open(uploaded_file).convert("RGB")
    image_array = np.array(image)
    width, height = image.size

    st.image(image, caption="Image for Labeling", use_column_width=True)

    st.markdown("### ✏️ Draw rectangles on the image")

    canvas_result = st_canvas(
        fill_color="rgba(255, 0, 0, 0.3)",
        stroke_width=2,
        background_image=image,
        update_streamlit=True,
        height=height,
        width=width,
        drawing_mode="rect",
        key="canvas"
    )

    if "results" not in st.session_state:
        st.session_state["results"] = []

    if st.button("📤 Extract Text and Label Boxes"):
        boxes = canvas_result.json_data["objects"]
        if boxes:
            for box in boxes:
                left = int(box["left"])
                top = int(box["top"])
                width = int(box["width"])
                height = int(box["height"])
                x1, y1, x2, y2 = left, top, left + width, top + height

                roi = image_array[y1:y2, x1:x2]
                ocr_result = ocr.ocr(roi, cls=True)
                extracted_text = ""
                if ocr_result and isinstance(ocr_result[0], list):
                    extracted_text = " ".join([line[1][0] for line in ocr_result[0]])

                label = st.text_input(f"Enter label for box at ({x1}, {y1})", key=f"label_{x1}_{y1}")

                result_entry = {
                    "coordinates": {"x1": x1, "y1": y1, "x2": x2, "y2": y2},
                    "text": extracted_text,
                    "label": label
                }
                st.session_state["results"].append(result_entry)

            st.success("✅ Text extracted and labeled.")

    if st.session_state["results"]:
        st.markdown("### 📋 Extracted Results")
        for i, r in enumerate(st.session_state["results"]):
            st.write(f"**{i+1}. Label:** {r['label']}")
            st.write(f"**Text:** {r['text']}")
            st.write(f"**Coordinates:** {r['coordinates']}")

        if st.button("💾 Save to JSON"):
            with open("labeled_output.json", "w") as f:
                json.dump(st.session_state["results"], f, indent=4)
            st.success("Saved to `labeled_output.json`")
