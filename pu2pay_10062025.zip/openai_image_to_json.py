import os
from openai import OpenAI
from apikey import OPENAI_API_KEY  # Make sure this exists and contains your key as a string

# ✅ Set environment variable or use directly
# Option 1: via env variable (optional if you prefer env vars)
os.environ["OPENAI_API_KEY"] = OPENAI_API_KEY

# ✅ Initialize client
client = OpenAI(api_key=OPENAI_API_KEY)

# ✅ Test a simple chat completion
try:
    response = client.chat.completions.create(
        model="gpt-3.5-turbo",  # or "gpt-4-turbo"
        messages=[
            {"role": "system", "content": "You are a helpful assistant."},
            {"role": "user", "content": "What is the capital of France?"}
        ]
    )

    print("✅ API key is working!")
    print("Response:", response.choices[0].message.content)

except Exception as e:
    print("❌ Error occurred:")
    print(e)
