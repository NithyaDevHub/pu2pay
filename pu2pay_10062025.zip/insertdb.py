import psycopg2



conn = psycopg2.connect(
    dbname="pu2pay_master_v1",
    user="postgres",
    password="12345",
    host="localhost",
    port="5433"
)
cur = conn.cursor()

with open("/Users/fis/Documents/pu2pay/cleaned_bkp_recon_as_integer.csv", "r") as f:
    cur.copy_expert("COPY reconciliation FROM STDIN WITH CSV HEADER", f)

conn.commit()
cur.close()
conn.close()
