from paddleocr import PaddleOCR
from PIL import Image
import os
from langchain_core.prompts import PromptTemplate
from langchain_core.output_parsers import StrOutputParser
from langchain.llms import Ollama
from datetime import datetime, timedelta  # ✅ Add timedelta here
from langchain_core.runnables import RunnableMap
import streamlit as st
import tempfile
import re

# Initialize OCR model once
ocr_model = PaddleOCR(use_angle_cls=True, lang='en')

# LLM initialization
llm = Ollama(model="llama3.1:latest", temperature=0)

# LangChain prompt
template = """
You are a recommendation agent.

From the invoice content below, extract the terms and conditions section and identify the due date or payment period.

Terms and content:
"{terms}"

The invoice date is: "{invoice_date}"

Now determine how many days are left until the due date or how many days have passed if it's overdue.
Give a simple recommendation like "X days left" or "Overdue by X days".

Return only the recommendation.
"""

prompt = PromptTemplate(
    input_variables=["terms", "invoice_date"],
    template=template
)

chain = prompt | llm | StrOutputParser()


def extract_text_from_image(image_path):
    results = ocr_model.ocr(image_path, cls=True)
    extracted_text = ""

    for line in results[0]:
        line_text = line[1][0]
        extracted_text += line_text + "\n"

    return extracted_text.strip()


def extract_due_days(terms: str) -> int:
    """Extracts the number of days (e.g., 'within 30 days') from the terms text."""
    match = re.search(r'(\d+)\s+days', terms.lower())
    if match:
        return int(match.group(1))
    return None  # fallback


def extract_terms_conditions(text: str) -> str:
    lines = text.splitlines()
    terms_start_keywords = ["terms and conditions", "terms:", "payment terms", "terms"]
    end_section_keywords = ["total", "amount", "signature", "authorized", "invoice number"]

    start_idx = None
    end_idx = None

    # Step 1: Find the starting line index
    for i, line in enumerate(lines):
        for keyword in terms_start_keywords:
            if keyword.lower() in line.lower():
                start_idx = i
                break
        if start_idx is not None:
            break

    # Step 2: If start found, find end index
    if start_idx is not None:
        for j in range(start_idx + 1, len(lines)):
            if any(k in lines[j].lower() for k in end_section_keywords):
                end_idx = j
                break
        # Slice out the terms section
        if end_idx:
            terms_section = "\n".join(lines[start_idx:end_idx])
        else:
            terms_section = "\n".join(lines[start_idx:])  # Until the end
        return terms_section.strip()

    return "Terms and Conditions section not found."



def get_recommendation(terms: str, invoice_date: str) -> str:
    try:
        # Step 1: Extract number of due days
        due_days = extract_due_days(terms)
        if not due_days:
            return "⚠️ Unable to extract due days from Terms & Conditions."

        # Step 2: Parse invoice date
        inv_date_obj = datetime.strptime(invoice_date, "%Y-%m-%d")
        due_date_obj = inv_date_obj + timedelta(days=due_days)
        today = datetime.today()
        
        # Step 3: Calculate recommendation
        delta = (due_date_obj - today).days
        if delta > 0:
            status = f"✅ {delta} days left"
        else:
            status = f"⚠️ Overdue by {abs(delta)} days"

        return f"📆 Due Date: {due_date_obj.strftime('%Y-%m-%d')}\n{status}"
    
    except Exception as e:
        return f"❌ Error during recommendation generation: {str(e)}"



# Streamlit UI
st.set_page_config(page_title="Invoice Recommendation Agent", layout="centered")
st.title("📄 Invoice Recommendation Agent")
st.write("Upload an invoice image containing Terms & Conditions and the invoice date.")

uploaded_file = st.file_uploader("Upload Image", type=["png", "jpg", "jpeg"])

if uploaded_file:
    with tempfile.NamedTemporaryFile(delete=False) as tmp_file:
        tmp_file.write(uploaded_file.read())
        image_path = tmp_file.name

    st.image(image_path, caption="Uploaded Image", use_container_width=True)

    if st.button("Recommend"):
        with st.spinner("Extracting and generating recommendation..."):
            full_text = extract_text_from_image(image_path)
            terms_text = extract_terms_conditions(full_text)

        # st.subheader("🔍 Raw OCR Output")
        # st.text_area("Full Text from OCR", full_text, height=250)

        st.subheader("📌 Extracted Terms & Conditions")
        st.text_area("Terms Section", terms_text, height=150)

        invoice_date = st.date_input("📅 Select Invoice Date")
        if invoice_date:
            with st.spinner("Generating Recommendation..."):
                recommendation = get_recommendation(terms_text, str(invoice_date))

            st.subheader("✅ Recommendation")
            st.success(recommendation)
