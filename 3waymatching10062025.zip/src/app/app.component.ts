import { Component, OnInit, OnChanges } from '@angular/core';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrl: './app.component.scss'
})
export class AppComponent implements OnInit, OnChanges {
  title = 'way-matching';
  isLoggedIn: boolean = false;


  constructor(private activatedRoute: ActivatedRoute) { }
  ngOnInit() {
    // Check if the user is logged in
    this.isLoggedIn = localStorage.getItem('isLoggedIn') === 'true' ? true : false;
  }
  ngOnChanges() {
    this.isLoggedIn = localStorage.getItem('isLoggedIn') === 'true' ? true : false;
  }
}
