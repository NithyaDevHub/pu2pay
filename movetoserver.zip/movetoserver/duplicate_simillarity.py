import os
import cv2
import numpy as np
import pandas as pd
from PaddleOCR.tools.infer import predict_system
from sklearn.metrics.pairwise import cosine_similarity
from difflib import SequenceMatcher
from paddleocr import PaddleOCR
from PIL import Image
import imagehash
from hashlib import md5
from tensorflow.keras.applications import ResNet50
from tensorflow.keras.applications.resnet50 import preprocess_input
from tensorflow.keras.models import Model

# Initialize PaddleOCR
ocr = PaddleOCR(use_angle_cls=True, lang='en')

# Define paths
IMAGE_DIR = "/Users/fis/Documents/pu2pay/output_images"

# Helper to check if file is an image
def is_image_file(file_path):
    valid_extensions = ('.png', '.jpg', '.jpeg', '.bmp', '.tiff', '.webp')
    return file_path.lower().endswith(valid_extensions)

# Function to perform OCR
def extract_text(image_path):
    result = ocr.ocr(image_path, cls=True)
    if result and isinstance(result[0], list):
        text = " ".join([line[1][0] for line in result[0]])
    else:
        text = ""
    return text

# Function to compute image hash
def compute_image_hash(image_path):
    img = Image.open(image_path)
    return str(imagehash.phash(img))

# Load ResNet50 model
base_model = ResNet50(weights='imagenet', include_top=False, pooling='avg')
model = Model(inputs=base_model.input, outputs=base_model.output)

def compute_feature_vector(image_path):
    img = cv2.imread(image_path)
    img = cv2.resize(img, (224, 224))
    img = preprocess_input(img)
    img = np.expand_dims(img, axis=0)
    features = model.predict(img)
    return features.flatten()

# Function to calculate text similarity
def text_similarity(text1, text2):
    return SequenceMatcher(None, text1, text2).ratio()

# Function for tampering detection using ELA
def detect_tampering(image_path):
    ela_image_path = image_path.replace(".png", "_ela.png")

    img = Image.open(image_path).convert('RGB')
    img.save(ela_image_path, 'JPEG', quality=90)
    temp_img = Image.open(ela_image_path)
    ela_img = Image.blend(img, temp_img, alpha=0.5)

    ela_array = np.array(ela_img) - np.array(temp_img)
    tampered_score = np.mean(ela_array)

    return tampered_score

# Main processing function
def process_images(image_dir):
    results = []
    file_hashes = {}
    feature_vectors = {}

    for file_name in os.listdir(image_dir):
        file_path = os.path.join(image_dir, file_name)
        if not os.path.isfile(file_path):
            continue
        if not is_image_file(file_path):
            print(f"Skipping non-image file: {file_path}")
            continue

        try:
            # Extract OCR text
            ocr_text = extract_text(file_path)

            # Compute image hash
            image_hash = compute_image_hash(file_path)

            # Compute feature vector
            feature_vector = compute_feature_vector(file_path)

            # Tampering detection
            tampering_score = detect_tampering(file_path)

            # Check for duplicates
            if image_hash in file_hashes:
                duplicate_status = "Exact Duplicate"
            else:
                duplicate_status = "Unique"
                file_hashes[image_hash] = file_name

            feature_vectors[file_name] = feature_vector

            results.append({
                "FileName": file_name,
                "OCR_Text": ocr_text,
                "Image_Hash": image_hash,
                "Tampering_Score": tampering_score,
                "Duplicate_Status": duplicate_status
            })

        except Exception as e:
            print(f"Error processing {file_path}: {e}")
            continue

    # Compute similarity between feature vectors and text
    similarity_results = []
    for file1, vec1 in feature_vectors.items():
        for file2, vec2 in feature_vectors.items():
            if file1 >= file2:
                continue  # Avoid duplicate comparisons and self-comparison

            similarity = cosine_similarity([vec1], [vec2])[0][0]

            text1 = next(item for item in results if item['FileName'] == file1)['OCR_Text']
            text2 = next(item for item in results if item['FileName'] == file2)['OCR_Text']
            text_sim = text_similarity(text1, text2)

            similarity_results.append({
                "File1": file1,
                "File2": file2,
                "Feature_Similarity": similarity,
                "Text_Similarity": text_sim
            })

    return results, similarity_results

# Run the process
image_results, similarity_results = process_images(IMAGE_DIR)

# Save results as CSV
pd.DataFrame(image_results).to_csv("image_results_sim.csv", index=False)
pd.DataFrame(similarity_results).to_csv("similarity_results_sim.csv", index=False)

print("Processing completed. Results saved.")
