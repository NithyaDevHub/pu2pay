import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { DashboardComponent } from './components/dashboard/dashboard.component';
import { StandardComponent } from './components/standard/standard.component';
import { ProcurementComponent } from './components/procurement/procurement.component';
import { ReviewComponent } from './components/review/review.component';
import { DataClassificationComponent } from './components/data-classification/data-classification.component';
import { DuplicateSimilarityComponent } from './components/duplicate-similarity/duplicate-similarity.component';
import { InvoiceChecklistComponent } from './components/invoice-checklist/invoice-checklist.component';
import { InvoiceAuditTrailComponent } from './components/invoice-audit-trail/invoice-audit-trail.component';
import { LoginComponent } from './components/login/login.component';
import { DashboardModernComponent } from './components/dashboard-modern/dashboard-modern.component';
import { EmailIntegrationComponent } from './components/email-integration/email-integration.component';

const routes: Routes = [

  {
    path:'projects',
    loadChildren: () => import('./components/projects/projects.module').then(m => m.ProjectsModule),
  },
  {
    path: 'dashboard',
    component: DashboardModernComponent,
  },
  {
    path: 'standard',
    component: StandardComponent
  },
  {
    path: 'Procurement',
    component: ProcurementComponent
  },
  {
    path: 'review',
    component: ReviewComponent
  },
  {
    path: 'data-clasification',
    component: DataClassificationComponent
  },
  {
    path: 'duplicat_similarity',
    component: DuplicateSimilarityComponent
  },
  {
    path: 'duplicat_similarity/:id',
    component: DuplicateSimilarityComponent
  },
  {
    path: 'invoice_check_list/:id/:batch_id',
    component: InvoiceChecklistComponent,

  },
  {
    path: 'po_list/:id',
    component: InvoiceAuditTrailComponent,

  },
  {
    path: 'email_integration',
    component: EmailIntegrationComponent,

  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
