import { ChangeDetectorRef, Component, ElementRef, ViewChild } from '@angular/core';
import { ProjectsService } from '../../services/projects.service';
import { Router } from '@angular/router';
import { animate, state, style, transition, trigger } from '@angular/animations';
import { FormBuilder, FormGroup } from '@angular/forms';

@Component({
  selector: 'app-data-classification',
  templateUrl: './data-classification.component.html',
  styleUrl: './data-classification.component.scss',
  animations: [
    trigger('splashAnimation', [
      state('show', style({
        opacity: 1
      })),
      state('hide', style({
        opacity: 0,
        pointerEvents: 'none'
      })),
      transition('show => hide', [
        animate('0.5s ease-out')
      ])
    ])
  ]
})
export class DataClassificationComponent {
  showSplash = false;
  splashState = 'show';
  splashProgress = 0;
  isAddCaseOpen = false;
  totalClaims = 11;
  totalPages = 286;
  selectedDocType: string = 'invoice'; // Default selected document type
  activeTab: string = 'upload';
  isdocumentVisible = false;
  pdf_list:any
  activeTabs: string = 'po'; // Default active tab
  cliamIds:any
  invoiceDetails:any;
  supplierDetails:any;
  buyerDetails:any;
  shippingDetails:any;
  invoiceLineItem:any;
  summaryLineItem:any;
  bankDetails:any;
  assetDetails:any;
  filetarget:any
  data: any ;
  based_on_cliamId_list:any
  classificaiton_data:any;
  imageDocView:any
  imagePath:any;
  claim_number:any;
  po_currentItem:any
  mrn_currentItem:any
  review_data:any
  invoice_currentItem:any
  image_path_mrn:any
  image_path_po:any
  image_path_invoice:any
  searchImage_value:any
  poLineItem: any;
  poDetails: any;
  termsAndConditions: any;
  image_duplicates_value:any
  searchInfoextracted:any;
  classification_obj!:FormGroup;
  selectedValue:any
  @ViewChild('canvas', { static: false }) canvas!: ElementRef<HTMLCanvasElement>;

searchText: string = 'INVOICE ID';
searchText1: string = 'romashka';
imageSrc: any; // Replace with your image
ctx!: CanvasRenderingContext2D;
detectedWords: any;
  // docList:any;
  // docCategoryList:any
  docCategoryList: Record<string, string[]> = {
    'Id Proof': ["Passport", "AadharCard", "VoterID", "PANCard"],
    'Diagnostic Report': ["DiagnosticReports", "Biocam", "Pathology", "Histpathology", "MicroBiology", "Heamatology", "Ultrasound", "MRI_CT_USG_Report","MRI_CT_USG_Scan",
      "X-ray",],
    'Discharge Summary': ["DischargeSummary"],
    'Medical Bills': ["HospitalBill", "MedicalBills", "Pharmasybills", "Opdbills"],
    'Claim Form': ["ClaimForm", "Letters", "Emails"],
    'Cheque': ["Cheque", "Bankpassbook", "Bankstatement"],
    // "X-ray & Scan":[ "MRI_CT_USG_Scan",
    //   "X-ray",],
     'Others':[ "Utility"]

  };

  based_on_cliamId_list_flag_list:any
  docList:any = [
   "Invoice",
    "PO",
    "MRN",
    "Utility",
    "Ewaybill",
  ]
cases: any[] = [];
  statuses = ['Exact Duplicate Found', 'Po No not mapped', 'Checklist Failed', 'Reconciliation'];

// statuses = ['Exact Duplicate Found', 'PO Not Mapped', 'Audit Complete', 'Reconciliation'];
currentStep = 0;

  tabs = [
    {
      id: 'upload',
      label: 'Upload',
      icon: `<svg class="icon" viewBox="0 0 24 24" width="20" height="20">
              <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"></path>
              <polyline points="17 8 12 3 7 8"></polyline>
              <line x1="12" y1="3" x2="12" y2="15"></line>
            </svg>`
    },
    {
      id: 'classification',
      label: 'Classification',
      icon: `<svg class="icon" viewBox="0 0 24 24" width="20" height="20">
              <path d="M20.59 13.41l-7.17 7.17a2 2 0 0 1-2.83 0L2 12V2h10l8.59 8.59a2 2 0 0 1 0 2.82z"></path>
              <line x1="7" y1="7" x2="7.01" y2="7"></line>
            </svg>`
    },
    {
      id: 'extraction',
      label: 'Extraction',
      icon: `<svg class="icon" viewBox="0 0 24 24" width="20" height="20">
              <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"></path>
              <polyline points="14 2 14 8 20 8"></polyline>
              <line x1="12" y1="18" x2="12" y2="12"></line>
              <line x1="9" y1="15" x2="15" y2="15"></line>
            </svg>`
    },
    {
      id: 'review',
      label: 'Review',
      icon: `<svg class="icon" viewBox="0 0 24 24" width="20" height="20">
              <circle cx="11" cy="11" r="8"></circle>
              <line x1="21" y1="21" x2="16.65" y2="16.65"></line>
            </svg>`
    }
  ];

  selectedTab = 'file';
  totalDocuments = 0;
  batchId = '';
  path = '';
  uploadedFiles: File[] = [];
  // cdr: any;

  constructor(private projectService: ProjectsService, private router:Router,private cdr: ChangeDetectorRef, private fb:FormBuilder) { }
  // constructor() { }

  ngOnInit(): void {
    // this.getData();
    this.pdf_conversion_hypotus()
    this.classification_details()
    // Component initialization logic if needed
    document.addEventListener('keydown', (event) => {
      if (event.key === 'Escape' && this.isAddCaseOpen) {
        this.closeAddCase();
      }
    });
    // this.animateSplashProgress();
      // this.currentStep = this.getStepFromStatus(this.case.status);

        this.classification_obj = this.fb.group({
      "claim_id" :[''],
      "img" :[''],
      "top_label":['']
    })
  }

   getStepFromStatus(status: string): number {
    const index = this.statuses.indexOf(status);
    return index >= 0 ? index + 1 : 0;
  }

  isStepCompleted(status: string, currentStep: number, expectedStatus: string, stepNumber: number): boolean {
    return currentStep >= stepNumber && this.statuses[stepNumber - 1] === expectedStatus;
  }

// getStepFromStatus(status: string): number {
//   const index = this.statuses.indexOf(status);
//   return index >= 0 ? index + 1 : 0;
// }

// isStepCompleted(expectedStatus: string, stepNumber: number): boolean {
//   return this.currentStep >= stepNumber && this.statuses[stepNumber - 1] === expectedStatus;
// }
  animateSplashProgress(): void {
    // Animate splash screen progress bar from 0 to 100%
    const startTime = performance.now();
    const duration = 3000; // 3 seconds

    const updateProgress = (currentTime: number) => {
      const elapsed = currentTime - startTime;
      const progress = Math.min(elapsed / duration, 1);

      // Use ease-out cubic for smoother progress
      this.splashProgress = Math.round(100 * (1 - Math.pow(1 - progress, 3)));

      if (progress < 1) {
        requestAnimationFrame(updateProgress);
      }
      this.cdr.detectChanges();
    };

    requestAnimationFrame(updateProgress);
  }

  // Get Invoice Data
  getData(claim_id:any) {
    // alert("Hi"+claim_id)
    // this.projectService.getInvoiceData().subscribe((data: any) => {
      this.projectService.getData('invoice',claim_id).subscribe((data: any) => {
         this.po_currentItem = { 'mapping_id':data.invoice_details.po_ref, "image":`assets/output_images/Change Order 5500382519_page1.png` ,"claim_id":claim_id}
      console.log("datadatadatadatadatadatadatadata", data)
      this.image_path_po = `assets/output_images/Change Order 5500382519_page1.png`;
      this.data = data;;
      this.invoiceDetails = data.invoice_details;
      this.supplierDetails = data.supplier_details[0];
      this.invoiceLineItem = data.line_items;
      this.summaryLineItem = data.summary;
      this.bankDetails = data.bank_details[0];
      this.assetDetails = data.asset_details;
      this.buyerDetails = data.buyer_details[0];
      this.shippingDetails = data.shipping_details[0];
      // this.data = data[0];
      console.log(data);

    });
  }
  // /Users/fis/Downloads/way-matching/way-matching/src/assets/output_images
  toggleInvoiceInfo(image:any) {
    this.isdocumentVisible = !this.isdocumentVisible;
    console.log("image", image)
    this.imageDocView = image
    this.imagePath = `assets/output_images/${image.claim_id}/${image.image}`;
    console.log("imagePath", this.imagePath)
      this.selectedValue = image.top_label
    this.classification_obj.controls['claim_id'].setValue(image.claim_id)
    this.classification_obj.controls['img'].setValue(image.image)
    this.classification_obj.controls['top_label'].setValue(image.top_label)
  }
  toggleInvoiceInfo_close(){
    this.isdocumentVisible = !this.isdocumentVisible;
  }
  toggleAddCase(): void {
    this.isAddCaseOpen = !this.isAddCaseOpen;

    if (this.isAddCaseOpen) {
      // Reset form when opening
      this.resetForm();
    }



  }

  closeAddCase(): void {
    this.isAddCaseOpen = false;
  }

  setTab(tab: string): void {
    this.selectedTab = tab;
  }

  handleFileUpload(event: any): void {
    const files = event.target.files;
    const file: File = event.target.files[0];
    // this.filetarget = event.target.files
    console.log(event.target.files)
    if (files && files.length) {
      this.uploadedFiles = Array.from(files);
      this.totalDocuments = this.uploadedFiles.length;
    }
    if (file) {
      this.filetarget = file;
    }
    console.log("event.target.files",event.target.files[0])
  }
  onDocTypeChange(event: any): void {
    this.selectedDocType = event.target.value;
    console.log("selectedDocType", this.selectedDocType);
    // You can add logic here to handle the change in document type
  }

  addCase(): void {
    // alert(this.selectedDocType);
    // return
    this.showSplash = true
    this.animateSplashProgress()
    // console.log("filetarget",this.filetarget)
    // if (!this.batchId) {
    //   alert('Batch ID is required');
    //   return;
    // }

    // // Generate a unique claim ID
    // const claimPrefix = Math.floor(Math.random() * 9000000) + 1000000;
    // const claimSuffix = Math.floor(Math.random() * 9) + 1;
    // const newClaimId = `${claimPrefix}-${claimSuffix}`;

    // // Create new case
    // const newCase = {
    //   batchId: this.batchId,
    //   claimId: newClaimId,
    //   noOfPdf: this.totalDocuments || Math.floor(Math.random() * 5) + 1,
    //   status: 'Pending',
    //   review: 'Review'
    // };


    // // Reset form and close panel


    // // Show success message
    // this.showSuccessMessage('Case added successfully');

    console.log("this.filetarget", this.filetarget)
    const formData = new FormData();
    formData.append('file', this.filetarget);
    this.projectService.upload(formData,this.selectedDocType).subscribe((response: any) => {
      console.log("response", response);
      if(response){
        this.showSplash = false
        if(response.process_result[0]['image_duplicates'] == 'No_Duplicate'){
          this.showSuccessMessage('Files uploaded successfully');
          this.router.navigate(['/data-clasification']);
        }else if(response.process_result[0]['image_duplicates'] == 'Po No not mapped'){
          this.showSuccessMessage('Po No not mapped');
          this.router.navigate([`/po_list/${response.process_result[0]['insert_id']}`]);
        }else{
          this.showSuccessMessage('Duplicate Similarity Analysis');
          this.router.navigate([`/duplicat_similarity/${response.process_result[0]['insert_id']}`]);
        }
      }
    } , (error:any) => {
      console.error('Error uploading files:', error);
      this.showSuccessMessage('Error uploading files');
    }
    );
        this.resetForm();
    this.closeAddCase();
  }

  resetForm(): void {
    this.batchId = '';
    this.path = '';
    this.totalDocuments = 0;
    this.uploadedFiles = [];
    this.selectedTab = 'file';
  }

  reviewCase(caseItem: any): void {
    // In a real app, navigate to case review page or open modal
    console.log('Reviewing case:', caseItem);
    // this.showSuccessMessage(`Reviewing case: ${caseItem.id}`);
    if(caseItem.status == 'Exact Duplicate Found'){
      // this.image_duplicates(caseItem.id)
      this.router.navigate([`/duplicat_similarity/${caseItem.id}`]);
    }else if(caseItem.status == "Checklist Failed"){
      // alert("HI")
      this.router.navigate([`/invoice_check_list/${caseItem.id}/${caseItem.claim_id}`]);
    }else if(caseItem.status == "Po No not mapped"){
      this.router.navigate([`/po_list/${caseItem.id}`]);
    }else{
      this.router.navigate(['/standard']);
    }

  }

  showSuccessMessage(message: string): void {
    // In a real app, use a proper toast/notification service
    alert(message);
  }
  toggleInvoiceInfo_1() {
    this.isdocumentVisible = !this.isdocumentVisible;
  }



  reviewImage(image: any): void {
    console.log('Reviewing image:', image);
    // Add logic to handle image review
  }

  summarizeClaim(claim: any): void {
    console.log('Summarizing claim:', claim);
    // Add logic to handle claim summarization
  }

  setActiveTab(tabId: string): void {
    this.activeTab = tabId;
    console.log("activeTab", this.activeTab)

    // if(tabId == 'extraction'){
    //   this.showextraction(this.claim_number)
    // }
  }

  // extraction
    onTabClick(tab: string): void {
      this.activeTabs = tab;

      if(this.activeTab == 'extraction'){
        // console.log("this.activeTab", this.activeTab)
        if(this.activeTabs == 'invoice'){
          console.log("activeTabs", this.activeTabs)
          this.ngAfterViewInit(this.image_path_invoice,this.invoice_currentItem.image)
          // this.testing(this.invoice_currentItem.image)
        }
        if(this.activeTabs == 'po'){
          console.log("activeTabs", this.activeTabs)
          // this.getData(claim_id)
          this.ngAfterViewInit(this.image_path_po,this.po_currentItem.image)
          // this.testing(this.po_currentItem.image)
        }
        if(this.activeTabs == 'mrn'){
          console.log("activeTabs", this.activeTabs)
          this.ngAfterViewInit(this.image_path_mrn,this.mrn_currentItem.image)
          // this.testing(this.mrn_currentItem.image)
        }

      }
    }
    onInputClick(e: any) {
      this.searchInImage(e); // Trigger highlighting when the input field is clicked
  }
    pdf_conversion_hypotus(){
      this.projectService.pdf_conversion_hypotus().subscribe((data: any) => {
        console.log("data here", data)
        this.cases = data.map((item:any) => {
          return {
            ...item,
            currentStep: this.getStepFromStatus(item.status)
          };
        });
        this.pdf_list = this.cases;
      })
    }
    classification_details(){
      this.projectService.classification_details().subscribe((data: any) => {
        console.log("classificaiton_data", data)
        console.log("classificaiton_data", data[0].claim_id)
        this.classificaiton_data = data
        // this.pdf_list = data;
        const cliamIds:any = [];
        data.map((res:any) => {
          cliamIds.push(res.claim_id)
        })
        //console.log("cliam id", cliamIds)
        //console.log("duplicate",cliamIds.filter((value:any, index:any) => cliamIds.indexOf(value) === index))
        this.cliamIds = cliamIds.filter((value:any, index:any) => cliamIds.indexOf(value) === index);
        console.log("cliamIds", this.cliamIds)


  //     const matchedObjects = res.filter((obj:any) => this.cliamIds.includes(obj.claim_id))
  // .reduce((acc:any, obj:any) => {
  //   acc[obj.claim_id] = obj;
  //   return acc;
  // }, {} as Record<string, typeof res[0]>);

  const matchedObjects = this.cliamIds.reduce((acc:any, value:any) => {
    // Find all objects in `objectsArray` with the matching `id`
    const matched = data.filter((obj:any) => obj.claim_id === value);
    //console.log("Matched values", matched)
    // If we found matches, add them to the accumulator object under the `id` key
    if (matched.length > 0) {
      matched.sort((a:any, b:any) => {
        if (a.top_label > b.top_label) {
          return 1; // b comes before a (ascending)
        } else if (a.top_label < b.top_label) {
          return -1; // a comes before b (ascending)
        }
        return 0; // a and b are equal
      });
      acc[value] = acc[value] ? acc[value].concat(matched) : matched;
    }

    return acc;
  }, {} as Record<string, typeof data[]>);


//Flag related code here

  const matchedObjects1 = this.cliamIds.reduce((acc:any, value:any) => {
    // Find all objects in `objectsArray` with the matching `id`
    const matchedvalues:any = []
    const matched = data.filter((obj:any) => obj.claim_id === value ? matchedvalues.push(obj.top_label) : '');
    //console.log("Matched values_1", matchedvalues)
    let uniqueArray = [...new Set(matchedvalues)];
    //console.log("Matched value test", uniqueArray)
    let result = this.docList.filter((value:any) => !uniqueArray.includes(value));
    //console.log("Matched value test result", result)
    // this.filterUnmatchedCategories(result)

    const unmatchedCategories:any = {};
    // const category:any='';
    // const items:any = ''
    Object.entries(this.docCategoryList).forEach(([category, items]) => {
      // Log the category and items for debugging
      //console.log(`Checking category: ${category}`);
      //console.log(`Items: ${items}`);

      // Ensure items is an array and check if it has any matches in arrayToCheck
      if (Array.isArray(items)) {
        const hasMatch = items.some(item => uniqueArray.includes(item));

        // Log if a match was found
        //console.log(`Match found in category '${category}': ${hasMatch}`);

        // If no items in this category match arrayToCheck, add it to unmatchedCategories
        if (!hasMatch) {
          unmatchedCategories[category] = items;
          //console.log(`No match found for category '${category}', added to unmatchedCategories.`);
        }
      }
    });


    //console.log("unmatchedCategories",unmatchedCategories);

    // const flagcount :any = []
    // Object.keys(unmatchedCategories)

    // If we found matches, add them to the accumulator object under the `id` key
    if (matched.length > 0) {
      acc[value] = acc[value] ? acc[value].concat(Object.keys(unmatchedCategories)) : Object.keys(unmatchedCategories);
    }

    return acc;
  }, {} as Record<string, typeof data[]>);

  //console.log("matchedObjects1matchedObjects1",matchedObjects1);
//console.log("matchedObjectsmatchedObjects",matchedObjects);
this.based_on_cliamId_list = matchedObjects
// this.based_on_cliamId_list_flag_list = matchedObjects1
this.based_on_cliamId_list_flag_list = matchedObjects1


console.log("based_on_cliamId_list_flag_list",this.based_on_cliamId_list)



      })
    }
    showextraction(claim:any){
      console.log("claim", claim)
      this.review_data = this.based_on_cliamId_list[claim]
      console.log("this.based_on_cliamId_list[claim]", this.based_on_cliamId_list[claim])
      this.projectService.showextraction(claim).subscribe((data: any) => {
        this.setActiveTab('extraction')
        console.log("showextraction", data)
        // this.pdf_list = data;
        const filteredArray = data.filter((item:any) => item.mapping_id !== null);
        this.claim_number = claim
        console.log("showextraction",filteredArray);
        filteredArray.map((item:any) => {
          console.log("item list", item)
          if(item.top_label == "MRN"){
            this.mrn_currentItem = { 'mapping_id':item.mapping_id, "image":item.image ,"claim_id":claim}
            this.image_path_mrn = `assets/output_images/${claim}/${item.image}`;
          }else if(item.top_label == "PO"){
            // alert("PO")
            this.po_currentItem = { 'mapping_id':item.mapping_id, "image":item.image ,"claim_id":claim}
            this.image_path_po = `assets/output_images/${claim}/${item.image}`;
          }else{

            this.invoice_currentItem = { 'mapping_id':item.mapping_id, "image":item.image ,"claim_id":claim}
            this.image_path_invoice = `assets/output_images/${claim}/${item.image}`;
            console.log(this.invoice_currentItem , "image_path_invoice", this.image_path_invoice)
            this.getData(item.mapping_id)
          }
        })
      })

    }

    ngAfterViewInit(image:any,testingItem:any) {
      // alert(image)
      // alert(testingItem)
      this.loadImage(image);
      // this.extractTextFromImage();
      this.detectedWords = this.testing(testingItem)
    }
    loadImage(image:any) {
      // alert("Hi")
      console.log("this.imageSrc;", image)
      const canvas = this.canvas.nativeElement;
      this.ctx = canvas.getContext('2d')!;
      const img = new Image();
      img.src = image;

      img.onload = () => {
        canvas.width = img.width;
        canvas.height = img.height;
        this.ctx.drawImage(img, 0, 0);
      };
      this.searchImage_value = image
    }
    searchInImage(e: any) {
      const searchValue = e.target.value.trim().toLowerCase();
      // alert(searchValue)
      // Clear canvas and redraw the image
      const img = new Image();
      img.src = this.searchImage_value;
      img.onload = () => {
          const canvas = this.canvas.nativeElement;
          this.ctx.clearRect(0, 0, canvas.width, canvas.height);
          this.ctx.drawImage(img, 0, 0);

          if (!searchValue) return; // If input is empty, don't highlight

          this.detectedWords.forEach((word:any) => {
            console.log("word.text.toLowerCase().includes(searchValue)", word.text.toLowerCase().includes(searchValue))
              if (word.text.toLowerCase().includes(searchValue)) {
                  const x = word.bbox[0][0]; // Top-left X
                  const y = word.bbox[0][1]; // Top-left Y
                  const width = word.bbox[1][0] - word.bbox[0][0]; // Width from x1 - x0
                  const height = word.bbox[2][1] - word.bbox[0][1]; // Height from y1 - y0

                  this.ctx.fillStyle = 'rgba(255, 255, 0, 0.5)'; // Yellow transparent highlight
                  this.ctx.fillRect(x, y, width, height);
              }
          });
      };
  }
  testing(image_path:any){
    console.log("image_path", image_path)
    // return this.searchInfoextracted =
    this.projectService.bbox_api(image_path).subscribe((data: any) => {
      console.log("testing", data)
      // this.imageSrc = data[0].image;
      this.detectedWords =JSON.parse(data[0].bbox);
      console.log("detectedWords", this.detectedWords)
      return this.detectedWords
    })
  }




  // getData() {

  //   this.projectService.getData('po',this.item.mapping_id).subscribe((data: any) => {
  //   this.data = data[0];
  //   this.poDetails = data.po_details;
  //   this.supplierDetails = data.supplier_details[0];
  //   this.buyerDetails = data.buyer_details[0];
  //   this.shippingDetails = data.shipping_details[0];
  //   this.poLineItem = data.line_items;
  //   this.summaryLineItem = data.summary;
  //   this.termsAndConditions = data.terms_and_conditions[0];
  //   this.image_path_image = data.image_path;
  //   this.image_path = `assets/output_images/${this.item.claim_id}/${this.item.image}`;
  //     console.log(data);
  //   });
  // }


 classification_Update(){
    // alert("Hi")
    var  data = {  "top_label": this.classification_obj.controls['top_label'].value}

    this.projectService.clasification_Update_Data(data,this.classification_obj.controls['img'].value).subscribe((res:any) => {
      // this.toaster.showSuccess("Succesfully Updated", "Success")
      this.toggleInvoiceInfo_close()
      this.classification_details()
    })

    //console.log("classification_obj", this.classification_obj.controls['top_label'].value)
    //console.log("classification_obj", this.classification_obj.controls['img'].value)
  }


}
